// ============================================================
//  backend/recipes.js  —  Local recipe database
//
//  Used by chatbot-route.js to instantly return ingredients
//  for known dishes WITHOUT hitting the Claude API.
//  For unknown dishes, the chatbot falls back to Claude.
// ============================================================

const recipes = {
  biryani:              { ingredients: [{ name: "Basmati Rice", quantity: "2 cups" }, { name: "Chicken", quantity: "500g" }, { name: "Onion", quantity: "2 large" }, { name: "Tomato", quantity: "2" }, { name: "Yogurt", quantity: "1/2 cup" }, { name: "Ghee", quantity: "3 tbsp" }, { name: "Biryani Masala", quantity: "2 tbsp" }, { name: "Mint Leaves", quantity: "handful" }, { name: "Saffron", quantity: "pinch" }, { name: "Oil", quantity: "2 tbsp" }] },
  dosa:                 { ingredients: [{ name: "Rice", quantity: "2 cups" }, { name: "Urad Dal", quantity: "1 cup" }, { name: "Fenugreek Seeds", quantity: "1/2 tsp" }, { name: "Salt", quantity: "to taste" }, { name: "Oil", quantity: "for cooking" }] },
  idli:                 { ingredients: [{ name: "Rice", quantity: "2 cups" }, { name: "Urad Dal", quantity: "1 cup" }, { name: "Fenugreek Seeds", quantity: "1/2 tsp" }, { name: "Salt", quantity: "to taste" }] },
  pongal:               { ingredients: [{ name: "Rice", quantity: "1 cup" }, { name: "Moong Dal", quantity: "1/2 cup" }, { name: "Ghee", quantity: "3 tbsp" }, { name: "Cumin Seeds", quantity: "1 tsp" }, { name: "Black Pepper", quantity: "1 tsp" }, { name: "Cashews", quantity: "10-12" }, { name: "Curry Leaves", quantity: "few" }] },
  chapati:              { ingredients: [{ name: "Wheat Flour", quantity: "2 cups" }, { name: "Salt", quantity: "1/2 tsp" }, { name: "Oil", quantity: "1 tbsp" }, { name: "Water", quantity: "as needed" }] },
  fried_rice:           { ingredients: [{ name: "Cooked Rice", quantity: "2 cups" }, { name: "Mixed Vegetables", quantity: "1 cup" }, { name: "Egg", quantity: "2" }, { name: "Soy Sauce", quantity: "2 tbsp" }, { name: "Garlic", quantity: "4 cloves" }, { name: "Spring Onion", quantity: "2" }, { name: "Oil", quantity: "2 tbsp" }] },
  noodles:              { ingredients: [{ name: "Noodles", quantity: "200g" }, { name: "Mixed Vegetables", quantity: "1 cup" }, { name: "Soy Sauce", quantity: "2 tbsp" }, { name: "Garlic", quantity: "3 cloves" }, { name: "Chilli Sauce", quantity: "1 tbsp" }, { name: "Oil", quantity: "2 tbsp" }] },
  omelette:             { ingredients: [{ name: "Eggs", quantity: "2" }, { name: "Onion", quantity: "1 small" }, { name: "Green Chilli", quantity: "1" }, { name: "Coriander Leaves", quantity: "handful" }, { name: "Salt", quantity: "to taste" }, { name: "Oil", quantity: "1 tbsp" }] },
  egg_curry:            { ingredients: [{ name: "Eggs", quantity: "4" }, { name: "Tomato", quantity: "2" }, { name: "Onion", quantity: "2" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Coriander Powder", quantity: "1 tsp" }, { name: "Cumin Powder", quantity: "1 tsp" }, { name: "Oil", quantity: "2 tbsp" }] },
  chicken_curry:        { ingredients: [{ name: "Chicken", quantity: "500g" }, { name: "Onion", quantity: "2" }, { name: "Tomato", quantity: "2" }, { name: "Ginger-Garlic Paste", quantity: "2 tbsp" }, { name: "Chicken Masala", quantity: "2 tbsp" }, { name: "Curd", quantity: "1/4 cup" }, { name: "Oil", quantity: "3 tbsp" }, { name: "Coriander Leaves", quantity: "for garnish" }] },
  paneer_butter_masala: { ingredients: [{ name: "Paneer", quantity: "200g" }, { name: "Butter", quantity: "2 tbsp" }, { name: "Tomato", quantity: "3" }, { name: "Cashews", quantity: "10" }, { name: "Cream", quantity: "1/4 cup" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Red Chilli Powder", quantity: "1 tsp" }, { name: "Kasuri Methi", quantity: "1 tsp" }] },
  sambar:               { ingredients: [{ name: "Toor Dal", quantity: "1 cup" }, { name: "Tomato", quantity: "2" }, { name: "Tamarind", quantity: "lemon-sized ball" }, { name: "Sambar Powder", quantity: "2 tbsp" }, { name: "Mixed Vegetables", quantity: "1 cup" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Oil", quantity: "1 tbsp" }] },
  rasam:                { ingredients: [{ name: "Tomato", quantity: "2" }, { name: "Tamarind", quantity: "small ball" }, { name: "Toor Dal", quantity: "2 tbsp" }, { name: "Black Pepper", quantity: "1 tsp" }, { name: "Cumin Seeds", quantity: "1 tsp" }, { name: "Mustard Seeds", quantity: "1/2 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Oil", quantity: "1 tsp" }] },
  upma:                 { ingredients: [{ name: "Rava (Semolina)", quantity: "1 cup" }, { name: "Onion", quantity: "1" }, { name: "Green Chilli", quantity: "2" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Oil", quantity: "2 tbsp" }, { name: "Salt", quantity: "to taste" }, { name: "Water", quantity: "2.5 cups" }] },
  poha:                 { ingredients: [{ name: "Flattened Rice (Poha)", quantity: "2 cups" }, { name: "Peanuts", quantity: "1/4 cup" }, { name: "Onion", quantity: "1" }, { name: "Potato", quantity: "1 small" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Turmeric Powder", quantity: "1/2 tsp" }, { name: "Lemon Juice", quantity: "1 tbsp" }, { name: "Oil", quantity: "2 tbsp" }] },
  pizza:                { ingredients: [{ name: "Pizza Base", quantity: "1" }, { name: "Mozzarella Cheese", quantity: "100g" }, { name: "Pizza Sauce", quantity: "3 tbsp" }, { name: "Bell Pepper", quantity: "1" }, { name: "Onion", quantity: "1 small" }, { name: "Tomato", quantity: "1" }, { name: "Oregano", quantity: "1 tsp" }] },
  burger:               { ingredients: [{ name: "Burger Buns", quantity: "2" }, { name: "Patty (Veg/Chicken)", quantity: "2" }, { name: "Lettuce", quantity: "2 leaves" }, { name: "Tomato", quantity: "1" }, { name: "Onion", quantity: "1" }, { name: "Mayonnaise", quantity: "2 tbsp" }, { name: "Cheese Slice", quantity: "2" }] },
  sandwich:             { ingredients: [{ name: "Bread", quantity: "4 slices" }, { name: "Butter", quantity: "2 tbsp" }, { name: "Cucumber", quantity: "1" }, { name: "Tomato", quantity: "1" }, { name: "Onion", quantity: "1 small" }, { name: "Cheese Slice", quantity: "2" }, { name: "Green Chutney", quantity: "2 tbsp" }] },
  pasta:                { ingredients: [{ name: "Pasta", quantity: "200g" }, { name: "Pasta Sauce", quantity: "1 cup" }, { name: "Garlic", quantity: "4 cloves" }, { name: "Olive Oil", quantity: "2 tbsp" }, { name: "Parmesan Cheese", quantity: "50g" }, { name: "Basil Leaves", quantity: "handful" }, { name: "Salt & Pepper", quantity: "to taste" }] },
  maggi:                { ingredients: [{ name: "Maggi Noodles", quantity: "1 packet" }, { name: "Water", quantity: "2 cups" }, { name: "Onion", quantity: "1 small (optional)" }, { name: "Tomato", quantity: "1 (optional)" }, { name: "Butter", quantity: "1 tsp (optional)" }] },
  aloo_paratha:         { ingredients: [{ name: "Wheat Flour", quantity: "2 cups" }, { name: "Potato", quantity: "2 large (boiled)" }, { name: "Green Chilli", quantity: "2" }, { name: "Coriander Leaves", quantity: "handful" }, { name: "Cumin Seeds", quantity: "1 tsp" }, { name: "Salt", quantity: "to taste" }, { name: "Ghee", quantity: "for cooking" }] },
  chole:                { ingredients: [{ name: "Chickpeas", quantity: "1 cup (soaked overnight)" }, { name: "Onion", quantity: "2" }, { name: "Tomato", quantity: "2" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Chole Masala", quantity: "2 tbsp" }, { name: "Amchur Powder", quantity: "1 tsp" }, { name: "Oil", quantity: "3 tbsp" }] },
  rajma:                { ingredients: [{ name: "Kidney Beans (Rajma)", quantity: "1 cup (soaked overnight)" }, { name: "Tomato", quantity: "2" }, { name: "Onion", quantity: "2" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Rajma Masala", quantity: "2 tbsp" }, { name: "Oil", quantity: "2 tbsp" }] },
  kheer:                { ingredients: [{ name: "Milk", quantity: "1 litre" }, { name: "Sugar", quantity: "1/2 cup" }, { name: "Basmati Rice", quantity: "1/4 cup" }, { name: "Cardamom Powder", quantity: "1/2 tsp" }, { name: "Cashews", quantity: "10" }, { name: "Raisins", quantity: "2 tbsp" }, { name: "Saffron", quantity: "few strands" }] },
  gulab_jamun:          { ingredients: [{ name: "Milk Powder", quantity: "1 cup" }, { name: "Sugar", quantity: "1.5 cups" }, { name: "Maida", quantity: "2 tbsp" }, { name: "Baking Soda", quantity: "1/4 tsp" }, { name: "Ghee", quantity: "1 tbsp" }, { name: "Milk", quantity: "1/4 cup" }, { name: "Oil", quantity: "for frying" }, { name: "Rose Water", quantity: "1 tsp" }] },
  halwa:                { ingredients: [{ name: "Rava (Semolina)", quantity: "1 cup" }, { name: "Ghee", quantity: "1/2 cup" }, { name: "Sugar", quantity: "3/4 cup" }, { name: "Water", quantity: "2.5 cups" }, { name: "Cardamom Powder", quantity: "1/2 tsp" }, { name: "Cashews", quantity: "10" }, { name: "Raisins", quantity: "2 tbsp" }] },
  salad:                { ingredients: [{ name: "Cucumber", quantity: "1" }, { name: "Tomato", quantity: "1" }, { name: "Onion", quantity: "1 small" }, { name: "Carrot", quantity: "1" }, { name: "Lemon Juice", quantity: "1 tbsp" }, { name: "Salt", quantity: "to taste" }, { name: "Chaat Masala", quantity: "1/2 tsp" }] },
  tea:                  { ingredients: [{ name: "Milk", quantity: "1 cup" }, { name: "Tea Powder", quantity: "1 tsp" }, { name: "Sugar", quantity: "1-2 tsp" }, { name: "Ginger", quantity: "small piece (optional)" }, { name: "Cardamom", quantity: "1 (optional)" }] },
  coffee:               { ingredients: [{ name: "Milk", quantity: "1 cup" }, { name: "Coffee Powder", quantity: "1 tsp" }, { name: "Sugar", quantity: "1-2 tsp" }, { name: "Water", quantity: "2 tbsp" }] },
  lemon_rice:           { ingredients: [{ name: "Cooked Rice", quantity: "2 cups" }, { name: "Lemon", quantity: "2" }, { name: "Peanuts", quantity: "1/4 cup" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Turmeric Powder", quantity: "1/2 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Green Chilli", quantity: "2" }, { name: "Oil", quantity: "2 tbsp" }] },
  curd_rice:            { ingredients: [{ name: "Cooked Rice", quantity: "2 cups" }, { name: "Curd", quantity: "1 cup" }, { name: "Milk", quantity: "1/4 cup" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Ginger", quantity: "small piece" }, { name: "Oil", quantity: "1 tbsp" }, { name: "Salt", quantity: "to taste" }] },
  tomato_rice:          { ingredients: [{ name: "Rice", quantity: "2 cups" }, { name: "Tomato", quantity: "3" }, { name: "Onion", quantity: "1" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Oil", quantity: "2 tbsp" }] },
  veg_pulao:            { ingredients: [{ name: "Basmati Rice", quantity: "2 cups" }, { name: "Mixed Vegetables", quantity: "1.5 cups" }, { name: "Onion", quantity: "1" }, { name: "Whole Spices", quantity: "1 tsp each" }, { name: "Ghee", quantity: "2 tbsp" }, { name: "Mint Leaves", quantity: "handful" }] },
  chicken_fry:          { ingredients: [{ name: "Chicken", quantity: "500g" }, { name: "Red Chilli Powder", quantity: "2 tsp" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Curd", quantity: "2 tbsp" }, { name: "Lemon Juice", quantity: "1 tbsp" }, { name: "Spices", quantity: "as needed" }, { name: "Oil", quantity: "for frying" }] },
  fish_fry:             { ingredients: [{ name: "Fish", quantity: "300g" }, { name: "Red Chilli Powder", quantity: "2 tsp" }, { name: "Turmeric Powder", quantity: "1/2 tsp" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Lemon Juice", quantity: "1 tbsp" }, { name: "Rice Flour", quantity: "2 tbsp" }, { name: "Oil", quantity: "for frying" }] },
  mutton_curry:         { ingredients: [{ name: "Mutton", quantity: "500g" }, { name: "Onion", quantity: "2" }, { name: "Tomato", quantity: "2" }, { name: "Ginger-Garlic Paste", quantity: "2 tbsp" }, { name: "Mutton Masala", quantity: "2 tbsp" }, { name: "Curd", quantity: "1/4 cup" }, { name: "Oil", quantity: "3 tbsp" }] },
  paneer_tikka:         { ingredients: [{ name: "Paneer", quantity: "200g" }, { name: "Curd", quantity: "1/4 cup" }, { name: "Tikka Masala", quantity: "2 tbsp" }, { name: "Lemon Juice", quantity: "1 tbsp" }, { name: "Bell Pepper", quantity: "1" }, { name: "Onion", quantity: "1" }, { name: "Oil", quantity: "2 tbsp" }] },
  veg_kurma:            { ingredients: [{ name: "Mixed Vegetables", quantity: "2 cups" }, { name: "Coconut", quantity: "1/2 cup (grated)" }, { name: "Cashews", quantity: "10" }, { name: "Onion", quantity: "1" }, { name: "Tomato", quantity: "1" }, { name: "Kurma Masala", quantity: "2 tsp" }, { name: "Oil", quantity: "2 tbsp" }] },
  avial:                { ingredients: [{ name: "Mixed Vegetables", quantity: "2 cups" }, { name: "Coconut", quantity: "1/2 cup (grated)" }, { name: "Curd", quantity: "1/4 cup" }, { name: "Cumin Seeds", quantity: "1 tsp" }, { name: "Green Chilli", quantity: "2" }, { name: "Curry Leaves", quantity: "few" }, { name: "Coconut Oil", quantity: "1 tbsp" }] },
  poriyal:              { ingredients: [{ name: "Vegetables of choice", quantity: "2 cups" }, { name: "Grated Coconut", quantity: "2 tbsp" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Urad Dal", quantity: "1 tsp" }, { name: "Curry Leaves", quantity: "few" }, { name: "Oil", quantity: "2 tbsp" }] },
  kootu:                { ingredients: [{ name: "Chana Dal / Toor Dal", quantity: "1 cup" }, { name: "Vegetables", quantity: "1 cup" }, { name: "Coconut", quantity: "1/4 cup" }, { name: "Cumin Seeds", quantity: "1 tsp" }, { name: "Mustard Seeds", quantity: "1 tsp" }, { name: "Oil", quantity: "1 tbsp" }] },
  payasam:              { ingredients: [{ name: "Milk", quantity: "1 litre" }, { name: "Sugar", quantity: "1/2 cup" }, { name: "Vermicelli / Rice", quantity: "1/4 cup" }, { name: "Cardamom Powder", quantity: "1/2 tsp" }, { name: "Cashews", quantity: "10" }, { name: "Ghee", quantity: "1 tbsp" }, { name: "Raisins", quantity: "2 tbsp" }] },
  laddu:                { ingredients: [{ name: "Besan", quantity: "1 cup" }, { name: "Sugar", quantity: "1 cup (powdered)" }, { name: "Ghee", quantity: "1/2 cup" }, { name: "Cardamom Powder", quantity: "1/2 tsp" }, { name: "Cashews", quantity: "10" }] },
  jalebi:               { ingredients: [{ name: "Maida", quantity: "1 cup" }, { name: "Sugar", quantity: "1.5 cups" }, { name: "Curd", quantity: "1/4 cup" }, { name: "Baking Soda", quantity: "pinch" }, { name: "Saffron", quantity: "few strands" }, { name: "Oil", quantity: "for frying" }] },
  mysore_pak:           { ingredients: [{ name: "Besan", quantity: "1 cup" }, { name: "Ghee", quantity: "1 cup" }, { name: "Sugar", quantity: "1.5 cups" }, { name: "Water", quantity: "1/2 cup" }, { name: "Cardamom Powder", quantity: "1/2 tsp" }] },
  vada:                 { ingredients: [{ name: "Urad Dal", quantity: "1 cup (soaked 4 hrs)" }, { name: "Green Chilli", quantity: "2" }, { name: "Ginger", quantity: "small piece" }, { name: "Curry Leaves", quantity: "few" }, { name: "Salt", quantity: "to taste" }, { name: "Oil", quantity: "for frying" }] },
  samosa:               { ingredients: [{ name: "Maida", quantity: "2 cups" }, { name: "Potato", quantity: "3 (boiled)" }, { name: "Peas", quantity: "1/4 cup" }, { name: "Cumin Seeds", quantity: "1 tsp" }, { name: "Coriander Powder", quantity: "1 tsp" }, { name: "Garam Masala", quantity: "1/2 tsp" }, { name: "Oil", quantity: "for frying" }] },
  pakora:               { ingredients: [{ name: "Besan", quantity: "1 cup" }, { name: "Onion", quantity: "2 (sliced)" }, { name: "Green Chilli", quantity: "2" }, { name: "Coriander Leaves", quantity: "handful" }, { name: "Red Chilli Powder", quantity: "1 tsp" }, { name: "Salt", quantity: "to taste" }, { name: "Oil", quantity: "for frying" }] },
  pav_bhaji:            { ingredients: [{ name: "Pav Buns", quantity: "4" }, { name: "Mixed Vegetables", quantity: "2 cups" }, { name: "Butter", quantity: "3 tbsp" }, { name: "Pav Bhaji Masala", quantity: "2 tbsp" }, { name: "Onion", quantity: "2" }, { name: "Tomato", quantity: "3" }, { name: "Lemon Juice", quantity: "1 tbsp" }] },
  pani_puri:            { ingredients: [{ name: "Puri (readymade)", quantity: "20" }, { name: "Potato", quantity: "2 (boiled)" }, { name: "Chickpeas", quantity: "1/4 cup" }, { name: "Tamarind Chutney", quantity: "1/4 cup" }, { name: "Mint Leaves", quantity: "handful" }, { name: "Cumin Powder", quantity: "1 tsp" }, { name: "Black Salt", quantity: "1 tsp" }] },
  bhel_puri:            { ingredients: [{ name: "Puffed Rice", quantity: "2 cups" }, { name: "Tamarind Chutney", quantity: "1/4 cup" }, { name: "Green Chutney", quantity: "2 tbsp" }, { name: "Onion", quantity: "1" }, { name: "Tomato", quantity: "1" }, { name: "Sev", quantity: "1/2 cup" }, { name: "Lemon Juice", quantity: "1 tbsp" }] },
  spring_roll:          { ingredients: [{ name: "Spring Roll Wrappers", quantity: "10" }, { name: "Cabbage", quantity: "1 cup (shredded)" }, { name: "Carrot", quantity: "1 (grated)" }, { name: "Bell Pepper", quantity: "1" }, { name: "Soy Sauce", quantity: "1 tbsp" }, { name: "Ginger-Garlic", quantity: "1 tsp" }, { name: "Oil", quantity: "for frying" }] },
  manchurian:           { ingredients: [{ name: "Cabbage", quantity: "1 cup" }, { name: "Carrot", quantity: "1" }, { name: "Maida", quantity: "1/4 cup" }, { name: "Cornflour", quantity: "2 tbsp" }, { name: "Soy Sauce", quantity: "2 tbsp" }, { name: "Garlic", quantity: "4 cloves" }, { name: "Green Onion", quantity: "2" }, { name: "Oil", quantity: "for frying" }] },
  shawarma:             { ingredients: [{ name: "Chicken", quantity: "300g" }, { name: "Pita Bread / Chapati", quantity: "2" }, { name: "Garlic Sauce", quantity: "2 tbsp" }, { name: "Lettuce", quantity: "handful" }, { name: "Tomato", quantity: "1" }, { name: "Onion", quantity: "1 small" }, { name: "Shawarma Masala", quantity: "1 tbsp" }] },
  tacos:                { ingredients: [{ name: "Tortilla Shells", quantity: "3" }, { name: "Chicken / Paneer", quantity: "200g" }, { name: "Lettuce", quantity: "handful" }, { name: "Tomato", quantity: "1" }, { name: "Sour Cream", quantity: "2 tbsp" }, { name: "Salsa", quantity: "2 tbsp" }, { name: "Cheese", quantity: "50g" }] },
  pancakes:             { ingredients: [{ name: "Maida / Wheat Flour", quantity: "1 cup" }, { name: "Milk", quantity: "1 cup" }, { name: "Egg", quantity: "1" }, { name: "Sugar", quantity: "2 tbsp" }, { name: "Baking Powder", quantity: "1 tsp" }, { name: "Butter", quantity: "2 tbsp" } ] },
  butter_chicken:       { ingredients: [{ name: "Chicken", quantity: "500g" }, { name: "Butter", quantity: "3 tbsp" }, { name: "Tomato", quantity: "3" }, { name: "Cream", quantity: "1/4 cup" }, { name: "Onion", quantity: "1" }, { name: "Cashews", quantity: "10" }, { name: "Kasuri Methi", quantity: "1 tsp" }, { name: "Ginger-Garlic Paste", quantity: "1 tbsp" }, { name: "Butter Chicken Masala", quantity: "2 tbsp" }] },
};

/**
 * Match user input text to a recipe key.
 * Tries exact key match first, then keyword-based fuzzy match.
 * Returns the recipe object or null if not found.
 */
function findRecipe(userText) {
  const text = userText.toLowerCase().replace(/[^a-z0-9 _]/g, ' ').trim();

  // Try direct key match
  const directKey = text.replace(/\s+/g, '_');
  if (recipes[directKey]) return { key: directKey, recipe: recipes[directKey] };

  // Keyword map: words that point to recipe keys
  const keywordMap = {
    biryani:        ['biryani', 'biriyani'],
    dosa:           ['dosa', 'dosai'],
    idli:           ['idli', 'idly', 'idlies'],
    pongal:         ['pongal', 'ven pongal'],
    chapati:        ['chapati', 'chapatti', 'roti', 'phulka'],
    fried_rice:     ['fried rice', 'friedrice'],
    noodles:        ['noodles', 'chow mein', 'hakka'],
    omelette:       ['omelette', 'omelet', 'egg omelette'],
    egg_curry:      ['egg curry', 'egg gravy', 'muttai curry'],
    chicken_curry:  ['chicken curry', 'chicken gravy', 'kuzhambu'],
    paneer_butter_masala: ['paneer butter masala', 'butter paneer', 'paneer makhani'],
    sambar:         ['sambar', 'sambhar'],
    rasam:          ['rasam', 'pepper rasam', 'tomato rasam'],
    upma:           ['upma', 'uppuma'],
    poha:           ['poha', 'aval', 'beaten rice', 'flattened rice'],
    pizza:          ['pizza'],
    burger:         ['burger', 'hamburger'],
    sandwich:       ['sandwich'],
    pasta:          ['pasta', 'spaghetti', 'penne'],
    maggi:          ['maggi', 'instant noodles'],
    aloo_paratha:   ['aloo paratha', 'potato paratha', 'stuffed paratha'],
    chole:          ['chole', 'chana', 'chickpea', 'chhole'],
    rajma:          ['rajma', 'kidney beans', 'rajma chawal'],
    kheer:          ['kheer', 'rice pudding', 'payasam kheer'],
    gulab_jamun:    ['gulab jamun', 'gulab jam'],
    halwa:          ['halwa', 'halva', 'sooji halwa', 'rava halwa'],
    salad:          ['salad'],
    tea:            ['tea', 'chai', 'masala tea', 'masala chai'],
    coffee:         ['coffee', 'filter coffee', 'cold coffee'],
    lemon_rice:     ['lemon rice', 'chitranna'],
    curd_rice:      ['curd rice', 'thayir sadam', 'dahi rice'],
    tomato_rice:    ['tomato rice'],
    veg_pulao:      ['pulao', 'pulav', 'veg pulao'],
    chicken_fry:    ['chicken fry', 'fried chicken', 'chicken 65'],
    fish_fry:       ['fish fry', 'fried fish', 'meen fry'],
    mutton_curry:   ['mutton curry', 'mutton gravy', 'lamb curry'],
    paneer_tikka:   ['paneer tikka', 'tikka'],
    veg_kurma:      ['kurma', 'korma', 'veg kurma'],
    avial:          ['avial', 'avyal'],
    poriyal:        ['poriyal', 'stir fry', 'sabzi'],
    kootu:          ['kootu', 'dal vegetable'],
    payasam:        ['payasam', 'vermicelli payasam'],
    laddu:          ['laddu', 'laddoo', 'besan laddu'],
    jalebi:         ['jalebi', 'jilapi'],
    mysore_pak:     ['mysore pak', 'mysorepak'],
    vada:           ['vada', 'medu vada', 'medu vadai', 'vadai'],
    samosa:         ['samosa', 'samosas'],
    pakora:         ['pakora', 'pakoda', 'bhajiya', 'fritters'],
    pav_bhaji:      ['pav bhaji', 'pavbhaji'],
    pani_puri:      ['pani puri', 'golgappa', 'puchka'],
    bhel_puri:      ['bhel puri', 'bhelpuri', 'bhel'],
    spring_roll:    ['spring roll', 'spring rolls'],
    manchurian:     ['manchurian', 'gobi manchurian', 'veg manchurian'],
    shawarma:       ['shawarma', 'shwarma'],
    tacos:          ['taco', 'tacos'],
    pancakes:       ['pancake', 'pancakes'],
    butter_chicken: ['butter chicken', 'murgh makhani', 'makhani'],
  };

  for (const [key, keywords] of Object.entries(keywordMap)) {
    if (keywords.some(kw => text.includes(kw))) {
      return { key, recipe: recipes[key] };
    }
  }

  return null;
}

module.exports = { recipes, findRecipe };
