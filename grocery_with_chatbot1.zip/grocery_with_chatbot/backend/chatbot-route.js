// ============================================================
//  backend/chatbot-route.js  —  Recipe + Shopping Chatbot API
//
//  STRATEGY:
//    1. Check local recipes.js database first (instant, no API call)
//    2. If recipe found → format a rich response with all ingredients
//    3. If not found → fall back to Claude AI
//
//  Endpoint:
//    POST /api/chatbot/message
//    Body: { messages: [ {role:'user', content:'...'}, ... ] }
//    Returns: { reply: string, source: 'local' | 'claude' }
// ============================================================

const express        = require('express');
const router         = express.Router();
const { findRecipe } = require('./recipes');

// ── Detect if user is asking to cook something ────────────────
const COOK_TRIGGERS = [
  'i want to cook', 'i want to make', 'how to cook', 'how to make',
  'recipe for', 'ingredients for', 'how do i cook', 'how do i make',
  'i am cooking', 'i m cooking', 'make me', 'cook me',
  'want to prepare', 'how to prepare', 'prepare', 'let me cook',
];

function isRecipeRequest(text) {
  const lower = text.toLowerCase();
  return COOK_TRIGGERS.some(t => lower.includes(t));
}

// ── Format a local recipe into a rich bot message ─────────────
function formatLocalRecipe(key, recipe, dishName) {
  const title = key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

  const greetings = [
    `Great choice! 🍽️ ${title} is a classic — here's everything you need:`,
    `Yum! Let's cook ${title} 🧑‍🍳 Here are the ingredients:`,
    `${title} coming right up! 🔥 Here's your shopping list:`,
    `Perfect pick! Here's what you need to make ${title}:`,
  ];
  const greeting = greetings[Math.floor(Math.random() * greetings.length)];

  const ingredientLines = recipe.ingredients
    .map(ing => `• ${ing.name} – ${ing.quantity}`)
    .join('\n');

  const tips = getTips(key);

  return `${greeting}\n\n### Ingredients\n${ingredientLines}\n\n### Tips\n${tips}\n\nTap any ingredient below to compare prices across Amazon, Flipkart, BigBasket, JioMart & Blinkit! 🛒`;
}

// ── Cooking tips per dish ──────────────────────────────────────
function getTips(key) {
  const tipMap = {
    dosa:                 '- Ferment the batter overnight for best results\n- Spread batter in thin circles on a hot iron tawa\n- Serve hot with coconut chutney and sambar',
    idli:                 '- Ferment batter for 8–10 hours in a warm place\n- Grease idli moulds with oil before pouring batter\n- Steam for exactly 10–12 minutes for soft idlis',
    biryani:              '- Marinate chicken for at least 2 hours for depth of flavour\n- Use aged Basmati rice for best texture\n- Dum cook on very low flame for the last 20 minutes',
    butter_chicken:       '- Char the chicken slightly for a smoky flavour\n- Blend the tomato-onion gravy smooth before adding cream\n- Kasuri methi at the end is the secret ingredient!',
    sambar:               '- Pressure cook toor dal until very soft\n- Add tamarind water after dal is cooked\n- Temper with mustard seeds and curry leaves at the end',
    upma:                 '- Dry roast rava until fragrant before adding water\n- Use 2.5x water to rava for the right consistency\n- Cover and cook on low flame for fluffy upma',
    poha:                 "- Rinse poha just before using — don't soak too early\n- Squeeze lemon right before serving for freshness\n- Add peanuts at the start for maximum crunch",
    maggi:                '- Use only 1.5 cups water for thicker Maggi\n- Add the masala when there is still some water left\n- Butter and an egg make it restaurant-style!',
    chole:                '- Soak chickpeas overnight and boil until soft\n- Adding a tea bag while boiling gives a dark colour\n- Tangy amchur powder makes it authentic',
    gulab_jamun:          '- Knead dough gently — overworking makes it hard\n- Fry on medium-low heat for even browning\n- Soak in warm (not hot) sugar syrup for best absorption',
  };
  return tipMap[key] || '- Use fresh ingredients for best flavour\n- Taste and adjust seasoning as you cook\n- Mise en place — prep all ingredients before you start cooking';
}

// ── System prompt for Claude fallback ─────────────────────────
const CHEFBOT_SYSTEM = `You are ChefBot, a friendly Indian recipe and grocery shopping assistant embedded in GrocerySmart.

When a user mentions a dish they want to cook, respond with:
1. A warm greeting line about the dish (1 sentence)
2. A "### Ingredients" section — each ingredient on its own line starting with "• " in format: "• Ingredient – Quantity"
3. A "### Tips" section with 2-3 bullet tips (starting with "- ")
4. End with: "Tap any ingredient below to compare prices across Amazon, Flipkart, BigBasket, JioMart & Blinkit!"

For follow-up questions answer helpfully and conversationally. Keep it friendly and focused on Indian home cooking.`;

// ── POST /api/chatbot/message ─────────────────────────────────
router.post('/message', async (req, res) => {
  const { messages } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages array is required' });
  }

  const lastUserMsg = messages[messages.length - 1];
  if (!lastUserMsg || lastUserMsg.role !== 'user') {
    return res.status(400).json({ error: 'Last message must be from user' });
  }

  const userText = lastUserMsg.content;

  // ── Step 1: Try local recipe database ───────────────────────
  if (isRecipeRequest(userText)) {
    const match = findRecipe(userText);
    if (match) {
      const reply = formatLocalRecipe(match.key, match.recipe);
      return res.json({ reply, source: 'local' });
    }
  }

  // ── Step 2: Fall back to Claude AI ──────────────────────────
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({
      error: 'ANTHROPIC_API_KEY is not set',
      detail: 'Copy backend/.env.example to backend/.env and add your Anthropic API key, then restart the server.'
    });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method:  'POST',
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model:      'claude-sonnet-4-20250514',
        max_tokens: 1200,
        system:     CHEFBOT_SYSTEM,
        messages,
      }),
    });

    const data = await response.json();
    if (data.error) {
      return res.status(502).json({ error: 'Upstream API error', detail: data.error.message });
    }

    const reply = (data.content || []).map(c => c.text || '').join('');
    res.json({ reply, source: 'claude' });

  } catch (err) {
    console.error('Chatbot route error:', err);
    res.status(500).json({ error: 'Failed to get chatbot response', detail: err.message });
  }
});

module.exports = router;
