// ============================================================
//  backend/server.js  —  Express backend for GrocerySmart
//
//  WHY this exists:
//    The browser version calls the Anthropic API directly.
//    That exposes your API key in DevTools → Network tab.
//    This server keeps the key safe on the backend and
//    proxies the request for you.
//
//  HOW TO RUN:
//    1. cd backend
//    2. npm install
//    3. Create a .env file:  ANTHROPIC_API_KEY=sk-ant-xxxx
//    4. node server.js
//    5. Open http://localhost:3001
// ============================================================

const express       = require('express');
const cors          = require('cors');
const path          = require('path');
const chatbotRouter = require('./chatbot-route');   // ← NEW: Recipe chatbot
require('dotenv').config();

const app  = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Serve the frontend from the parent folder
app.use(express.static(path.join(__dirname, '..')));

// ── Chatbot API route ──────────────────────────────────────
// POST /api/chatbot/message  { messages: [...] }
app.use('/api/chatbot', chatbotRouter);              // ← NEW

// ── POST /api/prices  ──────────────────────────────────────
// Body: { query: "Toor Dal 1kg" }
// Returns the raw Anthropic JSON response
app.post('/api/prices', async (req, res) => {
  const { query } = req.body;

  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'query is required' });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({
      error: 'ANTHROPIC_API_KEY is not set',
      detail: 'Copy backend/.env.example to backend/.env and add your Anthropic API key, then restart the server.'
    });
  }

  const today     = new Date();
  const todayFull = today.toLocaleDateString('en-IN', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  });

  const prompt = `Today is ${todayFull}. You are a grocery price comparison engine for Indian online grocery platforms.

Product searched: "${query}"

Return ONLY a valid JSON object (no markdown, no extra text) with exactly two keys:

1. "products": array of exactly 5 objects for platforms in this exact order: Amazon, Flipkart, BigBasket, JioMart, Blinkit.
Each object must have:
- "productName": exact full product name as listed on that platform, with brand and quantity (string)
- "price": today's actual selling price in INR (realistic integer)
- "mrp": maximum retail price (integer, always >= price)
- "discount": integer 2-30 (% off MRP)
- "availability": "In Stock" | "Few Left" | "Out of Stock"
- "delivery": "Express 2hr" | "Same Day" | "Next Day" | "1-2 Days" | "2-4 Days"
- "bankOffers": array of 2-3 bank/card offer strings

2. "globalOffers": array of exactly 6 objects:
- "platform": Amazon | Flipkart | BigBasket | JioMart | Blinkit
- "bank": bank name
- "title": short offer headline
- "description": 1 sentence with conditions
- "type": "cashback" | "discount" | "emi" | "upi"

Use realistic Indian market prices. Return only raw JSON.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method:  'POST',
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model:      'claude-sonnet-4-20250514',
        max_tokens: 1800,
        messages:   [{ role: 'user', content: prompt }],
      }),
    });

    const data  = await response.json();
    const text  = (data.content || []).map(c => c.text || '').join('');
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    res.json(parsed);

  } catch (err) {
    console.error('Anthropic API error:', err);
    res.status(500).json({ error: 'Failed to fetch prices', detail: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`\n✅  GrocerySmart backend running at http://localhost:${PORT}`);
  console.log(`   Frontend:  http://localhost:${PORT}`);
  console.log(`   API route: POST http://localhost:${PORT}/api/prices\n`);
});
