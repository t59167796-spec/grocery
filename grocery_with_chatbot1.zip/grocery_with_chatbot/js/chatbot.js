// ============================================================
//  chatbot.js  —  Recipe + Shopping Chatbot (Frontend)
//
//  Flow:
//    1. User types a dish name
//    2. POST to /api/chatbot/message (backend)
//    3. Backend checks local recipes.js DB first (instant!)
//    4. Falls back to Claude AI if not in DB
//    5. Ingredients rendered as clickable price-search buttons
// ============================================================

let chatHistory = [];
let isTyping    = false;

// ── Backend vs direct API detection ─────────────────────────
// If running via backend (localhost:3001), use /api/chatbot/message.
// If opening index.html directly, fall back to direct Claude call.
const USE_BACKEND = (
  window.location.hostname === 'localhost' ||
  window.location.hostname === '127.0.0.1'
);

// ── Initialize chatbot ───────────────────────────────────────
function initChatbot() {
  const chatMessages = document.getElementById('chatMessages');
  const chatInput    = document.getElementById('chatInput');
  const chatSendBtn  = document.getElementById('chatSendBtn');

  if (!chatMessages || chatMessages.dataset.ready === 'true') return;
  chatMessages.dataset.ready = 'true';

  chatSendBtn.addEventListener('click', sendChatMessage);
  chatInput.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
  });

  document.querySelectorAll('.recipe-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      chatInput.value = chip.dataset.query;
      sendChatMessage();
    });
  });

  if (chatHistory.length === 0) {
    appendBotMessage(
      `👋 Hi! I'm **ChefBot** 🧑‍🍳 — your recipe & grocery assistant!\n\nTell me what you'd like to cook and I'll list all the ingredients. Tap any ingredient to compare prices across 5 grocery platforms!\n\nTry: *"I want to cook dosa"* or pick a dish below 👇`,
      false
    );
  }
}

// ── Send message ─────────────────────────────────────────────
async function sendChatMessage() {
  const input = document.getElementById('chatInput');
  const msg   = input.value.trim();
  if (!msg || isTyping) return;

  input.value = '';
  isTyping = true;

  // Hide chips after first real message
  const chipsRow = document.getElementById('recipeSuggestionsRow');
  if (chipsRow) chipsRow.style.display = 'none';

  appendUserMessage(msg);
  chatHistory.push({ role: 'user', content: msg });

  showTypingIndicator();

  try {
    const { reply, source } = await fetchBotReply(chatHistory);
    removeTypingIndicator();
    appendBotMessage(reply, true, source);
    chatHistory.push({ role: 'assistant', content: reply });
  } catch (err) {
    removeTypingIndicator();
    appendBotMessage("⚠️ Sorry, couldn't connect right now. Please try again!");
    console.error('Chatbot error:', err);
  }

  isTyping = false;
  document.getElementById('chatInput').focus();
}

// ── Fetch reply from backend or direct API ───────────────────
async function fetchBotReply(history) {
  if (USE_BACKEND) {
    // Via backend — keeps API key safe, uses local DB
    const resp = await fetch('/api/chatbot/message', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ messages: history }),
    });
    if (!resp.ok) throw new Error(`Backend error: ${resp.status}`);
    return await resp.json(); // { reply, source: 'local' | 'claude' }
  } else {
    // Direct Claude API fallback (for file:// preview only)
    const SYSTEM = `You are ChefBot, a friendly Indian recipe assistant. When asked about a dish, list ingredients using "• Ingredient – Quantity" format under "### Ingredients", then add "### Tips" with 2-3 tips. End with "Tap any ingredient to compare prices!"`;
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:      'claude-sonnet-4-20250514',
        max_tokens: 1200,
        system:     SYSTEM,
        messages:   history,
      }),
    });
    const data  = await resp.json();
    if (data.error) throw new Error(data.error.message);
    const reply = (data.content || []).map(c => c.text || '').join('');
    return { reply, source: 'claude' };
  }
}

// ── Append user bubble ───────────────────────────────────────
function appendUserMessage(text) {
  const el = document.createElement('div');
  el.className = 'chat-bubble user-bubble';
  el.textContent = text;
  getChatContainer().appendChild(el);
  scrollChat();
}

// ── Append bot bubble ────────────────────────────────────────
function appendBotMessage(text, parseIngredients = true, source = null) {
  const wrapper = document.createElement('div');
  wrapper.className = 'bot-message-wrap';

  // Source badge
  if (source) {
    const badge = document.createElement('div');
    badge.className = `source-badge source-${source}`;
    badge.textContent = source === 'local' ? '⚡ Instant (Local DB)' : '🤖 Claude AI';
    wrapper.appendChild(badge);
  }

  const el = document.createElement('div');
  el.className = 'chat-bubble bot-bubble';
  el.innerHTML = renderBotText(text, parseIngredients);
  wrapper.appendChild(el);

  getChatContainer().appendChild(wrapper);

  // Bind ingredient search buttons
  el.querySelectorAll('.ingredient-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const ingredient = btn.dataset.ingredient;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      document.querySelector('.tab-btn[data-tab="search"]').classList.add('active');
      document.getElementById('tab-search').classList.add('active');
      document.getElementById('searchInput').value = ingredient;
      searchProduct();
    });
  });

  scrollChat();
}

// ── Render bot markdown into HTML ────────────────────────────
function renderBotText(text, parseIngredients) {
  let html = text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>');

  // Section headers
  html = html.replace(/^### (.+)$/gm, '<div class="bot-section-header">$1</div>');

  // Ingredient lines: "• Name – Qty"
  html = html.replace(/^• ([^–\n]+?)(?:\s*[–-]\s*(.+))?$/gm, (_, name, qty) => {
    const cleanName = name.trim();
    const qtyPart   = qty ? `<span class="ing-qty">– ${qty.trim()}</span>` : '';
    if (parseIngredients && cleanName.length > 1 && cleanName.length < 60) {
      return `<div class="ingredient-line">
        <button class="ingredient-btn" data-ingredient="${cleanName}" title="Find price on all platforms">
          🛒 ${cleanName}
        </button>${qtyPart}
      </div>`;
    }
    return `<div class="ingredient-line"><span class="ing-bullet">•</span> ${cleanName}${qtyPart}</div>`;
  });

  // Tip/bullet lines starting with "-"
  html = html.replace(/^- (.+)$/gm, '<div class="bot-bullet">▸ $1</div>');

  // Line breaks
  html = html.replace(/\n\n/g, '<br><br>').replace(/\n/g, '<br>');

  return html;
}

// ── Typing indicator ─────────────────────────────────────────
function showTypingIndicator() {
  const el = document.createElement('div');
  el.className = 'chat-bubble bot-bubble typing-indicator';
  el.id = 'typingIndicator';
  el.innerHTML = '<span></span><span></span><span></span>';
  getChatContainer().appendChild(el);
  scrollChat();
}
function removeTypingIndicator() {
  document.getElementById('typingIndicator')?.remove();
}

// ── Helpers ──────────────────────────────────────────────────
function getChatContainer() { return document.getElementById('chatMessages'); }
function scrollChat() {
  const c = getChatContainer();
  if (c) c.scrollTop = c.scrollHeight;
}

// ── Clear chat ───────────────────────────────────────────────
function clearChat() {
  chatHistory = [];
  const c = getChatContainer();
  if (c) { c.innerHTML = ''; c.dataset.ready = 'false'; }
  const chipsRow = document.getElementById('recipeSuggestionsRow');
  if (chipsRow) chipsRow.style.display = '';
  initChatbot();
}
