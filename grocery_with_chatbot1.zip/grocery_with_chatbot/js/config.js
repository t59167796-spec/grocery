// ============================================================
//  config.js  —  Platform definitions & shared constants
// ============================================================

const PLATFORMS = [
  {
    id:    'amazon',
    name:  'Amazon',
    color: '#ff9900',
    bg:    '#1a1200',
    short: 'AMZ',
    url:   q => `https://www.amazon.in/s?k=${q}`
  },
  {
    id:    'flipkart',
    name:  'Flipkart',
    color: '#2874f0',
    bg:    '#00103a',
    short: 'FK',
    url:   q => `https://www.flipkart.com/search?q=${q}`
  },
  {
    id:    'bigbasket',
    name:  'BigBasket',
    color: '#84c225',
    bg:    '#0e1a00',
    short: 'BB',
    url:   q => `https://www.bigbasket.com/ps/?q=${q}`
  },
  {
    id:    'jiomart',
    name:  'JioMart',
    color: '#e52531',
    bg:    '#1a0002',
    short: 'JIO',
    url:   q => `https://www.jiomart.com/search/${q}`
  },
  {
    id:    'blinkit',
    name:  'Blinkit',
    color: '#f7c948',
    bg:    '#1a1400',
    short: 'BLK',
    url:   q => `https://blinkit.com/s/?q=${q}`
  },
];

// Offer tag colours & labels
const OFFER_TAG_COLOR = { cashback: 'green', discount: 'blue', emi: 'orange', upi: 'green' };
const OFFER_TAG_LABEL = { cashback: 'Cashback', discount: 'Instant Discount', emi: 'No-Cost EMI', upi: 'UPI Offer' };

// Platform name → object lookup (built once at startup)
const PLATFORM_MAP = {};
PLATFORMS.forEach(p => { PLATFORM_MAP[p.name] = p; });
