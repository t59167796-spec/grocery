// ============================================================
//  api.js  —  Fetch prices & direct buy links from Claude API
// ============================================================

const cache = {};

async function fetchLivePrices(query) {
  const today = new Date();
  const key   = query.toLowerCase().trim() + '_' + today.toDateString();
  if (cache[key]) return cache[key];

  const prompt = `You are an Indian grocery price engine.
User search: "${query}"
Return ONLY valid JSON. No extra text.
Structure:
{
  "products": [
    {
      "platform": "Amazon | Flipkart | BigBasket | JioMart | Blinkit",
      "productName": "",
      "price": 0,
      "mrp": 0,
      "discount": 0,
      "unit": "kg | g | L | piece",
      "availability": "In Stock | Few Left | Out of Stock",
      "delivery": "Express 2hr | Same Day | Next Day | 1-2 Days | 2-4 Days",
      "bankOffers": ["offer string 1", "offer string 2"]
    }
  ],
  "globalOffers": [
    {
      "platform": "Amazon",
      "bank": "HDFC Bank",
      "title": "10% Instant Discount",
      "description": "On HDFC Debit & Credit Cards on min order ₹1500. Max ₹150.",
      "type": "discount"
    }
  ]
}
RULES (STRICT):
1. Return AT LEAST 50 total products (10 per platform).
2. Include products from ALL 5 platforms:
   - Amazon
   - Flipkart
   - BigBasket
   - JioMart
   - Blinkit
3. Prices MUST be realistic Indian market prices.
   Examples:
   - Tomato 1kg: ₹20–40
   - Onion 1kg: ₹25–50
   - Potato 1kg: ₹20–40
   - Rice 1kg: ₹60–150
   - Milk 1L: ₹50–80
   - Dal 1kg: ₹100–200
   - Atta 1kg: ₹40–70
   - Sugar 1kg: ₹40–55
   - Cooking Oil 1L: ₹120–180
4. Do NOT include fake URLs or image links — omit buyLink and image fields entirely.
5. Each product must have:
   - Realistic product name with brand + quantity (e.g. "Fresh Tomato 1kg", "Aashirvaad Atta 5kg")
   - Reasonable MRP always >= price
   - discount = round((mrp - price) / mrp * 100)
   - 1–2 realistic bankOffers strings per product
6. No random inflated prices (no ₹160 tomato ❌).
7. globalOffers: exactly 6 bank/card offers across varied platforms.
8. Return only clean JSON. No comments, no markdown, no backticks.`;

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:      'claude-sonnet-4-20250514',
        max_tokens: 8000,
        messages:   [{ role: 'user', content: prompt }]
      })
    });

    const data   = await resp.json();
    const text   = (data.content || []).map(c => c.text || '').join('');
    const clean  = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    const platformByName = {};
    PLATFORMS.forEach(p => { platformByName[p.name] = p; });

    const result = {
      products: parsed.products.map(item => {
        const platConfig = platformByName[item.platform] || PLATFORMS[0];
        const searchUrl  = platConfig.url(encodeURIComponent(item.productName));
        return {
          platform:      platConfig,
          productName:   item.productName,
          price:         item.price,
          mrp:           item.mrp,
          discount:      item.discount   || Math.round((item.mrp - item.price) / item.mrp * 100),
          availability:  item.availability || 'In Stock',
          delivery:      item.delivery    || '1-2 Days',
          bankOffers:    item.bankOffers  || [],
          deliveryHours: deliveryToHours(item.delivery || '1-2 Days'),
          unit:          item.unit        || '',
          buyLink:       searchUrl,   // search URL — no fake direct links
          image:         null,
        };
      }),
      globalOffers: parsed.globalOffers || []
    };

    cache[key] = result;
    return result;

  } catch (err) {
    console.error('API error, using fallback:', err);
    return getFallback(query);
  }
}

function deliveryToHours(label) {
  if (!label) return 72;
  if (label.includes('2hr'))  return 2;
  if (label.includes('Same')) return 8;
  if (label.includes('Next')) return 24;
  if (label.includes('1-2'))  return 36;
  return 72;
}

function getFallback(query) {
  const seed = query.toLowerCase().split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const base = 150 + (seed % 300);
  const DL   = ['Same Day','1-2 Days','2-4 Days','Express 2hr','Next Day'];
  const AV   = ['In Stock','In Stock','In Stock','Few Left','In Stock'];
  const BO   = [
    ['10% off with HDFC Credit Card (max ₹150)', 'No-cost EMI on HDFC/ICICI cards'],
    ['5% cashback on Axis Flipkart Credit Card', 'Extra 5% off with Axis Bank Debit Card'],
    ['10% off via BB Star Membership', '5% cashback on HDFC Credit Card'],
    ['Flat ₹100 off on JioPay first order', '5% cashback with JioMoney Wallet'],
    ['₹50 off via PhonePe UPI (min ₹299)', '10% cashback on Blinkit via Paytm'],
  ];

  return {
    products: PLATFORMS.map((p, i) => {
      const v   = ((seed * (i + 7) * 13) % 30) - 10;
      const d   = [8,12,5,15,10][i] + (seed % 8);
      const mrp = Math.round(base * 1.18);
      const price = Math.round(base * (1 + v / 100));
      return {
        platform: p, productName: query,
        price, mrp, discount: d,
        availability: AV[(i + seed * 2) % AV.length],
        delivery:     DL[(i + seed)     % DL.length],
        bankOffers:   BO[i],
        deliveryHours: [8, 36, 72, 2, 24][i],
        buyLink: p.url(encodeURIComponent(query)),
        image:   null,
      };
    }),
    globalOffers: [
      { platform:'Amazon',    bank:'HDFC Bank',        title:'10% Instant Discount',  description:'On HDFC Debit & Credit Cards on min order ₹1500. Max ₹150.',         type:'discount' },
      { platform:'Amazon',    bank:'Amazon Pay ICICI', title:'5% Cashback',            description:'Unlimited 5% cashback for Prime members on Amazon Pay ICICI Card.',   type:'cashback' },
      { platform:'Flipkart',  bank:'Axis Bank',        title:'5% Unlimited Cashback',  description:'On Axis Bank Flipkart Credit Card on all orders. No minimum.',         type:'cashback' },
      { platform:'BigBasket', bank:'SBI Card',         title:'Extra 5% Off',           description:'On SBI Credit Cards on orders above ₹499. Valid on weekdays.',         type:'discount' },
      { platform:'JioMart',   bank:'Kotak Bank',       title:'Flat ₹100 Off',          description:'On Kotak Credit/Debit Cards on minimum cart value ₹799.',             type:'discount' },
      { platform:'Blinkit',   bank:'PhonePe',          title:'₹50 Off via UPI',        description:'On PhonePe UPI payments. Minimum cart ₹299. Once per user per day.',  type:'upi'      },
    ]
  };
}
