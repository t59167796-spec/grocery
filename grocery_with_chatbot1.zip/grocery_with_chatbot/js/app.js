// ============================================================
//  app.js  —  Main app: search, sort, save products
// ============================================================

let currentData  = [];
let currentQuery = '';

// ── Bootstrap ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('searchBtn').addEventListener('click', searchProduct);

  document.getElementById('searchInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') searchProduct();
  });

  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.getElementById('searchInput').value = chip.dataset.query;
      searchProduct();
    });
  });

  document.querySelectorAll('.sort-btn').forEach(btn => {
    btn.addEventListener('click', () => sortResults(btn.dataset.sort, btn));
  });

  renderSavedPanel();
});

// ── Search flow ─────────────────────────────────────────────
async function searchProduct() {
  const query = document.getElementById('searchInput').value.trim();
  if (!query) return;
  currentQuery = query;

  document.getElementById('results').classList.remove('active');
  document.getElementById('loading').classList.add('active');

  const names = ['Amazon','Flipkart','BigBasket','JioMart','Blinkit'];
  let idx = 0;
  const scanEl = document.getElementById('scanningText');
  const ticker = setInterval(() => {
    if (idx < names.length) scanEl.textContent = `Fetching from ${names[idx++]}…`;
  }, 340);

  const result = await fetchLivePrices(query);
  clearInterval(ticker);

  currentData = result.products;
  renderResults(query, result);
  updateSaveBtn(query);

  document.getElementById('loading').classList.remove('active');
  document.getElementById('results').classList.add('active');
  document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Sorting ─────────────────────────────────────────────────
function sortResults(by, btn) {
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  if (by === 'price')    currentData.sort((a, b) => a.price - b.price);
  if (by === 'discount') currentData.sort((a, b) => b.discount - a.discount);
  if (by === 'delivery') currentData.sort((a, b) => a.deliveryHours - b.deliveryHours);
  renderPlatformCards(currentData, currentQuery);
  renderChart(currentData);
  renderPriceHistory(currentData);
}

// ── Save Product ─────────────────────────────────────────────
function getSavedProducts() {
  try { return JSON.parse(localStorage.getItem('gs_saved') || '[]'); } catch { return []; }
}
function setSavedProducts(list) {
  localStorage.setItem('gs_saved', JSON.stringify(list));
}

function saveCurrentProduct() {
  if (!currentData.length || !currentQuery) return;
  const saved = getSavedProducts();
  const key   = currentQuery.toLowerCase().trim();
  if (saved.find(p => p.key === key)) {
    showToast('Already saved!', 'info');
    return;
  }
  const best = [...currentData].sort((a, b) => a.price - b.price)[0];
  saved.unshift({
    key,
    query:       currentQuery,
    productName: best.productName,
    image:       best.image || null,
    bestPrice:   best.price,
    platform:    best.platform.name,
    buyLink:     best.buyLink,
    savedAt:     new Date().toISOString(),
    platforms:   currentData.map(d => ({
      name:    d.platform.name,
      color:   d.platform.color,
      price:   d.price,
      buyLink: d.buyLink,
    }))
  });
  setSavedProducts(saved);
  updateSaveBtn(currentQuery);
  renderSavedPanel();
  showToast(`✅ "${best.productName.slice(0,28)}…" saved!`, 'success');
}

function removeSaved(key) {
  setSavedProducts(getSavedProducts().filter(p => p.key !== key));
  renderSavedPanel();
}

function updateSaveBtn(query) {
  const btn   = document.getElementById('saveBtn');
  if (!btn) return;
  const saved = getSavedProducts();
  const already = saved.find(p => p.key === query.toLowerCase().trim());
  btn.textContent = already ? '✓ Saved' : '🔖 Save Product';
  btn.style.opacity  = already ? '0.6' : '1';
  btn.style.cursor   = already ? 'default' : 'pointer';
  btn.onclick        = already ? null : saveCurrentProduct;
}

// ── Render Saved Panel ───────────────────────────────────────
function renderSavedPanel() {
  const panel = document.getElementById('savedPanel');
  if (!panel) return;
  const saved = getSavedProducts();
  const badge = document.getElementById('savedCount');
  if (badge) badge.textContent = saved.length || '';

  if (!saved.length) {
    panel.innerHTML = `
    <div style="text-align:center;padding:48px 0;color:var(--muted)">
      <div style="font-size:2rem;margin-bottom:10px">🔖</div>
      <div style="font-size:.9rem">No saved products yet.</div>
      <div style="font-size:.8rem;margin-top:6px">Search a product and click <strong style="color:var(--accent)">Save Product</strong>.</div>
    </div>`;
    return;
  }

  panel.innerHTML = saved.map(item => `
  <div class="saved-card">
    <div class="saved-card-top">
      <div class="saved-img">
        ${item.image
          ? `<img src="${item.image}" style="width:48px;height:48px;object-fit:cover;border-radius:8px" onerror="this.style.display='none'">`
          : `<span style="font-size:1.5rem">🛒</span>`}
      </div>
      <div class="saved-meta">
        <div class="saved-name">${item.productName.length > 44 ? item.productName.slice(0,44)+'…' : item.productName}</div>
        <div class="saved-sub">Best: <strong style="color:var(--accent)">₹${item.bestPrice}</strong> on ${item.platform}
          &nbsp;·&nbsp; <span style="color:var(--muted);font-size:.72rem">Saved ${new Date(item.savedAt).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</span>
        </div>
      </div>
      <button class="saved-remove" onclick="removeSaved('${item.key}')" title="Remove">✕</button>
    </div>

    <!-- All platform prices -->
    <div class="saved-platforms">
      ${item.platforms.map(p => `
        <a href="${p.buyLink}" target="_blank" class="saved-plat-pill" style="border-color:${p.color}33">
          <span style="color:${p.color};font-size:.68rem;font-weight:700">${p.name}</span>
          <span style="font-size:.85rem;font-weight:700;color:var(--text)">₹${p.price}</span>
        </a>`).join('')}
    </div>

    <!-- Direct buy link -->
    <div class="saved-link-row">
      <div class="saved-link-url" title="${item.buyLink}">${item.buyLink}</div>
      <button class="copy-btn" onclick="copyLink('${item.buyLink.replace(/'/g,"\\'")}',this)">📋 Copy</button>
      <a class="open-btn" href="${item.buyLink}" target="_blank">Open →</a>
    </div>
  </div>`).join('');
}

// ── Toast notification ───────────────────────────────────────
function showToast(msg, type = 'info') {
  document.getElementById('gs-toast')?.remove();
  const colors = { success: 'var(--accent)', info: 'var(--accent2)', warn: 'var(--warn)' };
  const t = document.createElement('div');
  t.id = 'gs-toast';
  t.style.cssText = `position:fixed;bottom:24px;right:24px;z-index:9999;background:var(--surface);
    border:1px solid ${colors[type]};color:var(--text);border-radius:12px;padding:13px 18px;
    font-size:.85rem;max-width:300px;line-height:1.5;box-shadow:0 4px 20px rgba(0,0,0,.4);
    animation:fadeUp .25s ease`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

// ── Tab switching ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    });
  });
});
