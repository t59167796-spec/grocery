// ============================================================
//  url.js  —  Paste Product URL tab logic
// ============================================================

let urlCurrentData  = [];
let urlCurrentQuery = '';
let urlPriceHistoryInstance = null;

// ── Platform URL Detector ────────────────────────────────────
const URL_PATTERNS = [
  { name: 'Amazon',    color: '#ff9900', regex: /amazon\.in/i },
  { name: 'Flipkart',  color: '#2874f0', regex: /flipkart\.com/i },
  { name: 'BigBasket', color: '#84c225', regex: /bigbasket\.com/i },
  { name: 'JioMart',   color: '#e52531', regex: /jiomart\.com/i },
  { name: 'Blinkit',   color: '#f7c948', regex: /blinkit\.com/i },
];

function detectPlatform(url) {
  for (const p of URL_PATTERNS) {
    if (p.regex.test(url)) return p;
  }
  return null;
}

function extractProductHint(url) {
  try {
    const u = new URL(url);
    // Amazon: /dp/ASIN or title in path
    const pathParts = u.pathname.split('/').filter(Boolean);
    // Try to find a readable slug
    const slug = pathParts.find(p => p.length > 6 && !/^[A-Z0-9]{10}$/.test(p) && p !== 'dp' && p !== 'gp');
    if (slug) return decodeURIComponent(slug.replace(/-/g, ' '));
    // Fallback: search query param
    const q = u.searchParams.get('q') || u.searchParams.get('query') || u.searchParams.get('s');
    if (q) return decodeURIComponent(q);
  } catch {}
  return null;
}

// ── Bootstrap ────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const urlInput      = document.getElementById('urlInput');
  const urlCompareBtn = document.getElementById('urlCompareBtn');
  const detectBadge   = document.getElementById('urlDetectBadge');
  const inputWrap     = urlInput?.closest('.url-input-wrap');

  // Live platform detect on input
  urlInput?.addEventListener('input', () => {
    const val = urlInput.value.trim();
    const plat = detectPlatform(val);
    if (plat && val.startsWith('http')) {
      detectBadge.style.display = 'inline-flex';
      detectBadge.style.color = plat.color;
      detectBadge.style.borderColor = plat.color + '55';
      detectBadge.style.background = plat.color + '12';
      detectBadge.innerHTML = `<span style="width:7px;height:7px;background:${plat.color};border-radius:50%;display:inline-block"></span> Detected: <strong>${plat.name}</strong>`;
      inputWrap?.classList.add('detected');
    } else {
      detectBadge.style.display = 'none';
      inputWrap?.classList.remove('detected');
    }
  });

  urlInput?.addEventListener('keydown', e => {
    if (e.key === 'Enter') compareByUrl();
  });

  urlCompareBtn?.addEventListener('click', compareByUrl);

});

// ── Main URL compare flow ────────────────────────────────────
async function compareByUrl() {
  const urlInput = document.getElementById('urlInput');
  const rawUrl = urlInput.value.trim();
  if (!rawUrl) return;

  const plat = detectPlatform(rawUrl);
  const hint = extractProductHint(rawUrl) || 'grocery product';

  // Show loading
  document.getElementById('url-results').classList.remove('active');
  document.getElementById('url-loading').classList.add('active');

  const scanEl = document.getElementById('urlScanningText');
  const steps = [
    'Detecting platform…',
    `Reading product from ${plat ? plat.name : 'the link'}…`,
    'Matching product across all 5 platforms…',
    'Fetching live prices…',
    'Building price history…',
  ];
  let si = 0;
  const ticker = setInterval(() => {
    if (si < steps.length) scanEl.textContent = steps[si++];
  }, 500);

  const result = await fetchPricesByUrl(rawUrl, hint, plat);
  clearInterval(ticker);

  urlCurrentData  = result.products;
  urlCurrentQuery = result.productName;

  renderUrlResults(result, rawUrl, plat);

  document.getElementById('url-loading').classList.remove('active');
  document.getElementById('url-results').classList.add('active');
  document.getElementById('url-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Fetch prices by URL via Claude API ──────────────────────
async function fetchPricesByUrl(url, hint, detectedPlatform) {
  const prompt = `You are an Indian grocery price comparison engine.
A user has shared this product URL: "${url}"
The URL appears to be from: ${detectedPlatform ? detectedPlatform.name : 'an Indian grocery platform'}
Product hint from URL: "${hint}"

Your job: Identify the exact product this URL refers to, then return realistic current Indian market prices for that SAME product across all 5 platforms.

Return ONLY valid JSON, no extra text, no markdown:
{
  "productName": "Full product name with brand and quantity e.g. Aashirvaad Atta 5kg",
  "category": "grocery category",
  "sourceUrl": "${url}",
  "products": [
    {
      "platform": "Amazon | Flipkart | BigBasket | JioMart | Blinkit",
      "productName": "exact or equivalent product name on this platform",
      "price": 0,
      "mrp": 0,
      "discount": 0,
      "unit": "kg | g | L | piece",
      "availability": "In Stock | Few Left | Out of Stock",
      "delivery": "Express 2hr | Same Day | Next Day | 1-2 Days | 2-4 Days",
      "bankOffers": ["offer string 1", "offer string 2"],
      "isSourcePlatform": false
    }
  ],
  "globalOffers": [
    {
      "platform": "Amazon",
      "bank": "HDFC Bank",
      "title": "10% Instant Discount",
      "description": "On HDFC Debit & Credit Cards on min order ₹1500. Max ₹150.",
      "type": "discount"
    }
  ]
}

RULES (STRICT):
1. Return exactly 5 products — ONE per platform: Amazon, Flipkart, BigBasket, JioMart, Blinkit.
2. Mark isSourcePlatform: true for the platform matching the given URL.
3. Prices MUST be realistic current Indian market prices for this specific product.
4. discount = round((mrp - price) / mrp * 100). MRP always >= price.
5. 1-2 realistic bankOffers per product.
6. globalOffers: exactly 6 bank/card offers across varied platforms.
7. productName at top level: the canonical product name (brand + size) for display.
8. Return only clean JSON. No comments, no markdown, no backticks.`;

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data   = await resp.json();
    const text   = (data.content || []).map(c => c.text || '').join('');
    const clean  = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    const platformByName = {};
    PLATFORMS.forEach(p => { platformByName[p.name] = p; });

    return {
      productName: parsed.productName || hint,
      category: parsed.category || '',
      sourceUrl: url,
      products: parsed.products.map(item => {
        const platConfig = platformByName[item.platform] || PLATFORMS[0];
        const searchUrl  = platConfig.url(encodeURIComponent(item.productName));
        return {
          platform:         platConfig,
          productName:      item.productName,
          price:            item.price,
          mrp:              item.mrp,
          discount:         item.discount || Math.round((item.mrp - item.price) / item.mrp * 100),
          availability:     item.availability || 'In Stock',
          delivery:         item.delivery    || '1-2 Days',
          bankOffers:       item.bankOffers  || [],
          deliveryHours:    deliveryToHours(item.delivery || '1-2 Days'),
          unit:             item.unit || '',
          buyLink:          item.isSourcePlatform ? url : searchUrl,
          isSourcePlatform: item.isSourcePlatform || false,
          image:            null,
        };
      }),
      globalOffers: parsed.globalOffers || []
    };
  } catch (err) {
    console.error('URL API error:', err);
    return getUrlFallback(hint, url, detectedPlatform);
  }
}

function getUrlFallback(hint, url, detectedPlatform) {
  const seed = hint.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const base = 100 + (seed % 250);
  return {
    productName: hint,
    sourceUrl: url,
    products: PLATFORMS.map((p, i) => {
      const v   = ((seed * (i + 7) * 13) % 30) - 10;
      const mrp = Math.round(base * 1.18);
      const price = Math.round(base * (1 + v / 100));
      return {
        platform: p, productName: hint,
        price, mrp, discount: Math.round((mrp - price) / mrp * 100),
        availability: 'In Stock', delivery: ['Same Day','1-2 Days','2-4 Days','Express 2hr','Next Day'][i],
        bankOffers: ['10% off with HDFC Card', '5% cashback via UPI'],
        deliveryHours: [8, 36, 72, 2, 24][i],
        buyLink: detectedPlatform && p.name === detectedPlatform.name ? url : p.url(encodeURIComponent(hint)),
        isSourcePlatform: detectedPlatform && p.name === detectedPlatform.name,
        image: null,
      };
    }),
    globalOffers: []
  };
}

// ── Render URL Results ───────────────────────────────────────
function renderUrlResults(result, rawUrl, plat) {
  result.products.sort((a, b) => a.price - b.price);
  renderUrlChart(result.products);
  renderUrlPriceHistory(result.products);
}

function renderUrlProductHero(product, productName, rawUrl, plat) {
  document.getElementById('urlProductHero').innerHTML = `
  <div class="product-hero">
    <div class="product-img-wrap">${renderImage(product, 90)}</div>
    <div class="product-meta">
      <h2>${productName}</h2>
      <p>Compared across <strong style="color:var(--accent)">5 platforms</strong> &nbsp;·&nbsp; ${dateStr}</p>
      ${plat ? `<div style="margin-top:6px;display:flex;align-items:center;gap:8px">
        <span style="font-size:.75rem;color:var(--muted)">Source link:</span>
        <a href="${rawUrl}" target="_blank" style="font-size:.75rem;color:${plat.color};text-decoration:none;overflow:hidden;text-overflow:ellipsis;max-width:320px;display:inline-block;white-space:nowrap" title="${rawUrl}">${rawUrl}</a>
        <button class="copy-btn" onclick="copyLink('${rawUrl.replace(/'/g,"\\'")}',this)" style="font-size:.7rem;padding:3px 7px">📋</button>
      </div>` : ''}
    </div>
  </div>`;
}

function renderUrlBestDeal(best) {
  const saved = best.mrp - best.price;
  document.getElementById('urlBestDeal').innerHTML = `
  <div style="display:flex;align-items:center;gap:16px">
    <div style="width:60px;height:60px;border-radius:12px;background:rgba(0,230,118,.08);border:1px solid rgba(0,230,118,.2);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0">
      ${renderImage(best, 60)}
    </div>
    <div>
      <div class="best-badge">🏆 Best Deal Today</div>
      <h3>${best.productName}</h3>
      <div class="best-platform">on <strong style="color:${best.platform.color}">${best.platform.name}</strong>
        ${best.unit ? `&nbsp;·&nbsp; <span style="color:var(--muted);font-size:.8rem">per ${best.unit}</span>` : ''}
        &nbsp;·&nbsp; ⚡ ${best.delivery}</div>
    </div>
  </div>
  <div style="text-align:center">
    <div class="best-price">₹${best.price}</div>
    <div class="best-saving">Save ₹${saved} &nbsp;(${best.discount}% off MRP ₹${best.mrp})</div>
    ${best.bankOffers && best.bankOffers[0] ? `<div style="font-size:.76rem;color:var(--accent2);margin-top:6px">🏦 ${best.bankOffers[0]}</div>` : ''}
  </div>
  <div style="display:flex;flex-direction:column;gap:8px;min-width:150px">
    <a class="buy-btn" href="${best.buyLink}" target="_blank" rel="noopener">Buy on ${best.platform.name} →</a>
    <button class="btn-secondary" style="text-align:center" onclick="copyLink('${best.buyLink.replace(/'/g,"\\'")}',this)">📋 Copy Link</button>
  </div>`;
}

function renderUrlStats(data) {
  const prices = data.map(d => d.price);
  const min = Math.min(...prices), max = Math.max(...prices);
  const avg = Math.round(prices.reduce((a, b) => a + b) / prices.length);
  const maxD = Math.max(...data.map(d => d.discount));

  document.getElementById('urlStatsRow').innerHTML = `
  <div class="stat-card"><div class="stat-label">Lowest Price</div><div class="stat-value" style="color:var(--accent)">₹${min}</div><div class="stat-sub">${data.find(d => d.price === min).platform.name}</div></div>
  <div class="stat-card"><div class="stat-label">Highest Price</div><div class="stat-value" style="color:var(--danger)">₹${max}</div><div class="stat-sub">${data.find(d => d.price === max).platform.name}</div></div>
  <div class="stat-card"><div class="stat-label">Avg Price</div><div class="stat-value" style="color:var(--accent2)">₹${avg}</div><div class="stat-sub">Across 5 platforms</div></div>
  <div class="stat-card"><div class="stat-label">You could save</div><div class="stat-value" style="color:var(--warn)">₹${max - min}</div><div class="stat-sub">Vs highest price</div></div>
  <div class="stat-card"><div class="stat-label">Max Discount</div><div class="stat-value" style="color:var(--accent)">${maxD}%</div><div class="stat-sub">Best offer</div></div>`;
}

function renderUrlPlatformCards(data, query) {
  // One card per platform (sorted by price)
  document.getElementById('urlPlatformCards').innerHTML = `
  <div class="product-grid" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr))">
    ${data.map((d, i) => {
      const acCls  = d.availability === 'In Stock' ? 'avail-yes' : d.availability === 'Few Left' ? 'avail-few' : 'avail-no';
      const acIcon = d.availability === 'In Stock' ? '✓' : d.availability === 'Few Left' ? '⚠' : '✗';
      const isSrc  = d.isSourcePlatform;
      return `
      <div class="product-tile ${i === 0 ? 'tile-best' : ''}" style="animation-delay:${i * 0.07}s;${isSrc ? `border-color:${d.platform.color}55;` : ''}">
        <div class="tile-img" style="width:100%;height:44px;display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:6px">
          <span style="width:10px;height:10px;background:${d.platform.color};border-radius:50%;display:inline-block;flex-shrink:0"></span>
          <span style="font-size:.82rem;font-weight:800;color:${d.platform.color}">${d.platform.name}</span>
          ${isSrc ? `<span style="font-size:.62rem;background:${d.platform.color}22;color:${d.platform.color};border:1px solid ${d.platform.color}44;border-radius:6px;padding:1px 5px;font-weight:700">SOURCE</span>` : ''}
        </div>
        <div class="tile-body">
          <div class="tile-name" title="${d.productName}" style="font-size:.78rem">${d.productName.length > 40 ? d.productName.slice(0,40)+'…' : d.productName}</div>
          <div class="tile-price-row" style="margin-top:6px">
            <span class="tile-price" style="color:${i === 0 ? 'var(--accent)' : 'var(--text)'}">₹${d.price}</span>
            ${d.mrp > d.price ? `<span class="tile-mrp">₹${d.mrp}</span>` : ''}
            ${d.discount > 0 ? `<span class="tile-dis">-${d.discount}%</span>` : ''}
          </div>
          <div class="tile-meta" style="margin-top:4px">
            <span class="${acCls}" style="font-size:.7rem">${acIcon} ${d.availability}</span>
          </div>
          <div style="font-size:.7rem;color:var(--muted);margin-top:2px">⚡ ${d.delivery}</div>
        </div>
        <div class="tile-actions" style="margin-top:8px">
          <a class="btn-buy" href="${d.buyLink}" target="_blank" rel="noopener" style="font-size:.74rem;padding:6px 10px">${isSrc ? 'Open Original →' : 'Buy →'}</a>
          <button class="copy-btn" onclick="copyLink('${d.buyLink.replace(/\\/g,'\\\\').replace(/'/g,"\\'")}',this)" style="font-size:.7rem;padding:4px 8px">📋</button>
        </div>
        ${d.bankOffers && d.bankOffers[0] ? `<div class="tile-offer">🏦 ${d.bankOffers[0]}</div>` : ''}
        ${i === 0 ? `<div class="tile-best-badge">⭐ Best Price</div>` : ''}
      </div>`;
    }).join('')}
  </div>`;
}

function renderGlobalOffersTo(containerId, offers) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!offers || !offers.length) {
    el.innerHTML = '<p style="color:var(--muted);font-size:.85rem">No offers available.</p>';
    return;
  }
  el.innerHTML = offers.map(o => {
    const p  = PLATFORM_MAP[o.platform] || { color:'#8b949e', bg:'#21262d', short:'?' };
    const tc = OFFER_TAG_COLOR[o.type]  || 'blue';
    const tl = OFFER_TAG_LABEL[o.type]  || o.type;
    return `
    <div class="offer-card">
      <div class="offer-icon" style="background:${p.bg};color:${p.color};border:1px solid ${p.color}44">${p.short}</div>
      <div class="offer-body">
        <div class="offer-platform-name">${o.platform} &nbsp;·&nbsp; ${o.bank}</div>
        <div class="offer-title">${o.title}</div>
        <div class="offer-desc">${o.description}</div>
        <span class="offer-tag ${tc}">${tl}</span>
      </div>
    </div>`;
  }).join('');
}

function renderUrlChart(data) {
  const maxP = Math.max(...data.map(d => d.price));
  document.getElementById('urlBarChart').innerHTML = data.map(d => {
    const pct = Math.round((d.price / maxP) * 100);
    return `
    <div class="bar-row">
      <div class="bar-label">${d.platform.name}${d.isSourcePlatform ? ' ★' : ''}</div>
      <div class="bar-track">
        <div class="bar-fill url-bar" data-pct="${pct}" style="background:${d.platform.color};width:0%">₹${d.price}</div>
      </div>
    </div>`;
  }).join('');

  requestAnimationFrame(() => {
    document.querySelectorAll('.url-bar').forEach(b => {
      setTimeout(() => { b.style.width = b.dataset.pct + '%'; }, 50);
    });
  });
}

function renderUrlPriceHistory(data) {
  const labels = getDateLabels(30);
  const datasets = data.map(p => ({
    label: p.platform.name + (p.isSourcePlatform ? ' ★' : ''),
    data: generatePriceHistory(p.price, 30),
    borderColor: p.platform.color,
    backgroundColor: p.platform.color + '18',
    pointBackgroundColor: p.platform.color,
    pointRadius: p.isSourcePlatform ? 3 : 2,
    pointHoverRadius: 6,
    borderWidth: p.isSourcePlatform ? 3 : 2,
    tension: 0.42,
    fill: false,
  }));

  if (urlPriceHistoryInstance) {
    urlPriceHistoryInstance.destroy();
    urlPriceHistoryInstance = null;
  }

  const ctx = document.getElementById('urlPriceHistoryChart');
  if (!ctx) return;

  urlPriceHistoryInstance = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets },
    options: {
      responsive: true,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            color: '#a0aec0',
            font: { size: 12, family: "'DM Sans', sans-serif" },
            usePointStyle: true,
            pointStyleWidth: 10,
            boxHeight: 6,
            padding: 16,
          }
        },
        tooltip: {
          backgroundColor: '#1a1a2e',
          borderColor: '#2d2d4e',
          borderWidth: 1,
          titleColor: '#e2e8f0',
          bodyColor: '#a0aec0',
          padding: 12,
          callbacks: { label: ctx => ` ${ctx.dataset.label}: ₹${ctx.parsed.y}` }
        }
      },
      scales: {
        x: {
          ticks: { color: '#718096', font: { size: 10.5 }, maxRotation: 0, maxTicksLimit: 8 },
          grid: { color: 'rgba(255,255,255,0.04)' },
          border: { color: 'rgba(255,255,255,0.08)' }
        },
        y: {
          ticks: { color: '#718096', font: { size: 11 }, callback: v => '₹' + v },
          grid: { color: 'rgba(255,255,255,0.06)' },
          border: { color: 'rgba(255,255,255,0.08)' }
        }
      }
    }
  });

  // History stat cards
  const statsEl = document.getElementById('urlHistoryStats');
  if (!statsEl) return;
  statsEl.innerHTML = data.map((p, i) => {
    const hist = datasets[i].data;
    const minP = Math.min(...hist), maxP = Math.max(...hist);
    const first = hist[0], last = hist[hist.length - 1];
    const change = last - first;
    const changePct = Math.abs(Math.round((change / first) * 100));
    const trendClass = change > 2 ? 'trend-up' : change < -2 ? 'trend-down' : 'trend-flat';
    const trendText  = change > 2 ? `▲ +₹${change} this month` : change < -2 ? `▼ -₹${Math.abs(change)} this month` : '→ Stable';
    return `
    <div class="hstat-card" ${p.isSourcePlatform ? `style="border-color:${p.platform.color}44"` : ''}>
      <div class="hstat-platform" style="color:${p.platform.color}">${p.platform.name}${p.isSourcePlatform ? ' ★' : ''}</div>
      <div class="hstat-row"><span>Today</span><strong>₹${last}</strong></div>
      <div class="hstat-row"><span>30-day low</span><strong>₹${minP}</strong></div>
      <div class="hstat-row"><span>30-day high</span><strong>₹${maxP}</strong></div>
      <div class="hstat-trend ${trendClass}">${trendText} (${changePct}%)</div>
    </div>`;
  }).join('');
}

// ── Save URL product ─────────────────────────────────────────
function saveUrlProduct() {
  if (!urlCurrentData.length || !urlCurrentQuery) return;
  const saved = getSavedProducts();
  const key   = urlCurrentQuery.toLowerCase().trim();
  if (saved.find(p => p.key === key)) { showToast('Already saved!', 'info'); return; }

  const best = [...urlCurrentData].sort((a, b) => a.price - b.price)[0];
  saved.unshift({
    key,
    query:       urlCurrentQuery,
    productName: best.productName,
    image:       best.image || null,
    bestPrice:   best.price,
    platform:    best.platform.name,
    buyLink:     best.buyLink,
    savedAt:     new Date().toISOString(),
    platforms:   urlCurrentData.map(d => ({
      name: d.platform.name, color: d.platform.color,
      price: d.price, buyLink: d.buyLink,
    }))
  });
  setSavedProducts(saved);
  renderSavedPanel();
  showToast(`✅ "${best.productName.slice(0,28)}…" saved!`, 'success');
}

function updateUrlSaveBtn(query) {
  const btn = document.getElementById('urlSaveBtn');
  if (!btn) return;
  const already = getSavedProducts().find(p => p.key === query.toLowerCase().trim());
  btn.textContent = already ? '✓ Saved' : '🔖 Save Product';
  btn.style.opacity = already ? '0.6' : '1';
  btn.onclick = already ? null : saveUrlProduct;
}
