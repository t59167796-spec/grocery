// ============================================================
//  images.js  —  Product image lookup (Wikimedia URLs + emoji)
// ============================================================

const IMG_MAP = [
  [['basmati','rice'],                  'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Uncooked_rice.jpg/320px-Uncooked_rice.jpg'],
  [['sunflower oil'],                   'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Sunflower_oil_and_sunflower.jpg/320px-Sunflower_oil_and_sunflower.jpg'],
  [['toor','arhar dal','pigeon pea'],   'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/Split_pigeon_peas_or_toor_dal.jpg/320px-Split_pigeon_peas_or_toor_dal.jpg'],
  [['moong dal'],                       'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Mung_beans_small.jpg/320px-Mung_beans_small.jpg'],
  [['chana dal','chickpea'],            'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Chickpeas_and_peas.jpg/320px-Chickpeas_and_peas.jpg'],
  [['butter','amul'],                   'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Butter_block.jpg/320px-Butter_block.jpg'],
  [['atta','wheat flour','aashirvaad'], 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Wheat_ground_into_flour.jpg/320px-Wheat_ground_into_flour.jpg'],
  [['sugar','shakkar'],                 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Sugar_2xmacro.jpg/320px-Sugar_2xmacro.jpg'],
  [['maggi','noodle','instant noodle'],'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Noodles.jpg/320px-Noodles.jpg'],
  [['parle','biscuit','glucose biscuit'],'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Cookie_choco.jpg/320px-Cookie_choco.jpg'],
  [['milk','doodh'],                    'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Cow_milk_in_glass.jpg/320px-Cow_milk_in_glass.jpg'],
  [['tea','chai','masala tea'],         'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/A_small_cup_of_tea.jpg/320px-A_small_cup_of_tea.jpg'],
  [['coffee','nescafe'],                'https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/A_small_cup_of_coffee.JPG/320px-A_small_cup_of_coffee.JPG'],
  [['salt','namak'],                    'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Salt_shaker_on_white_background.jpg/320px-Salt_shaker_on_white_background.jpg'],
  [['ghee','desi ghee'],                'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Ghee-vegetable-oil.jpg/320px-Ghee-vegetable-oil.jpg'],
  [['paneer'],                          'https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Paneer_Cheese.jpg/320px-Paneer_Cheese.jpg'],
  [['egg','anda'],                      'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Egg_p_mathrubhumi.jpg/320px-Egg_p_mathrubhumi.jpg'],
  [['bread','pav'],                     'https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Fresh_made_bread_05.jpg/320px-Fresh_made_bread_05.jpg'],
  [['turmeric','haldi'],                'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Whole_and_ground_turmeric.jpg/320px-Whole_and_ground_turmeric.jpg'],
  [['cumin','jeera'],                   'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Cumin_seeds.jpg/320px-Cumin_seeds.jpg'],
  [['mustard','sarson'],                'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Mustard_seeds.jpg/320px-Mustard_seeds.jpg'],
  [['chilli','mirch'],                  'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Dried_chilli_pepper.jpg/320px-Dried_chilli_pepper.jpg'],
  [['coriander','dhania'],              'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Coriander_seeds.jpg/320px-Coriander_seeds.jpg'],
  [['masala','spice'],                  'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Indian-spices.jpg/320px-Indian-spices.jpg'],
  [['oil','cooking oil'],               'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Sunflower_oil_and_sunflower.jpg/320px-Sunflower_oil_and_sunflower.jpg'],
  [['dal','lentil','pulse'],            'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/Split_pigeon_peas_or_toor_dal.jpg/320px-Split_pigeon_peas_or_toor_dal.jpg'],
  [['tomato'],                          'https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Tomato_je.jpg/320px-Tomato_je.jpg'],
  [['potato','aloo'],                   'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Potato_je.jpg/320px-Potato_je.jpg'],
  [['onion','pyaz'],                    'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Onion-from-Silesia.jpg/320px-Onion-from-Silesia.jpg'],
];

const EMOJI_MAP = {
  rice:'🌾', oil:'🫙', dal:'🥜', butter:'🧈', atta:'🌾', flour:'🌾',
  sugar:'🍬', milk:'🥛', tea:'🍵', coffee:'☕', salt:'🧂', noodle:'🍜',
  maggi:'🍜', biscuit:'🍪', ghee:'🧈', masala:'🌶️', spice:'🌶️',
  paneer:'🧀', bread:'🍞', egg:'🥚', tomato:'🍅', potato:'🥔', onion:'🧅'
};

/**
 * Returns { type: 'img', src: '...' } or { type: 'emoji', val: '...' }
 */
function getProductImage(name) {
  const n = (name || '').toLowerCase();
  for (const [keys, url] of IMG_MAP) {
    if (keys.some(k => n.includes(k))) return { type: 'img', src: url };
  }
  for (const [k, v] of Object.entries(EMOJI_MAP)) {
    if (n.includes(k)) return { type: 'emoji', val: v };
  }
  return { type: 'emoji', val: '🛒' };
}

/**
 * Returns an <img> or <span> HTML string for a given image object and pixel size.
 */
function imgHTML(image, size) {
  if (image.type === 'img') {
    return `<img src="${image.src}" alt="product"
      style="width:${size}px;height:${size}px;object-fit:cover;border-radius:10px;"
      onerror="this.parentElement.innerHTML='🛒';this.parentElement.style.fontSize='${Math.round(size * 0.5)}px'">`;
  }
  return `<span style="font-size:${Math.round(size * 0.5)}px">${image.val}</span>`;
}
