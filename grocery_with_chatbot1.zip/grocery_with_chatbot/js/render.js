// ============================================================
//  render.js  —  Rendering for 50-product multi-platform view
// ============================================================

const today   = new Date();
const dateStr = today.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('liveDateBadge').innerHTML = `Prices as of <strong>${dateStr}</strong>`;
  document.getElementById('footerDate').textContent  = dateStr;
});

// ── Image helper ────────────────────────────────────────────
function renderImage(product, size) {
  if (product.image) {
    return `<img src="${product.image}" alt="${product.productName}"
      style="width:${size}px;height:${size}px;object-fit:cover;border-radius:8px;"
      onerror="this.outerHTML='<span style=\\'font-size:${Math.round(size*0.45)}px\\'>🛒</span>'">`;
  }
  const fallback = getProductImage(product.productName || '');
  return imgHTML(fallback, size);
}

// ── Copy link helper ────────────────────────────────────────
function copyLink(url, btn) {
  navigator.clipboard.writeText(url).then(() => {
    const orig = btn.textContent;
    btn.textContent = '✓ Copied!';
    btn.style.color = 'var(--accent)';
    setTimeout(() => { btn.textContent = orig; btn.style.color = ''; }, 1800);
  });
}

// ── Main orchestrator ───────────────────────────────────────
function renderResults(query, result) {
  document.getElementById('queryLabel').textContent = query;

  // Sort all products by price
  result.products.sort((a, b) => a.price - b.price);

  // Best deal = cheapest overall
  const best = result.products[0];
  renderProductHero(best, query);
  renderBestDeal(best);
  renderStats(result.products);
  renderPlatformTabs(result.products, query);
  renderGlobalOffers(result.globalOffers);
  renderChart(result.products);
  renderPriceHistory(result.products);
}

// ── Product hero (best overall) ─────────────────────────────
function renderProductHero(product, query) {
  document.getElementById('productHero').innerHTML = `
  <div class="product-hero">
    <div class="product-img-wrap">${renderImage(product, 90)}</div>
    <div class="product-meta">
      <h2>${product.productName}</h2>
      <p>Found <strong style="color:var(--accent)">${document.querySelectorAll ? '' : '50+'}</strong> listings across 5 platforms &nbsp;·&nbsp; ${dateStr}</p>
      <span class="searched-query">🔍 "${query}"</span>
    </div>
  </div>`;
}

// ── Best deal banner ────────────────────────────────────────
function renderBestDeal(best) {
  const saved = best.mrp - best.price;
  document.getElementById('bestDeal').innerHTML = `
  <div style="display:flex;align-items:center;gap:16px">
    <div style="width:60px;height:60px;border-radius:12px;background:rgba(0,230,118,.08);border:1px solid rgba(0,230,118,.2);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0">
      ${renderImage(best, 60)}
    </div>
    <div>
      <div class="best-badge">🏆 Best Deal Today</div>
      <h3>${best.productName}</h3>
      <div class="best-platform">on <strong style="color:${best.platform.color}">${best.platform.name}</strong>
        ${best.unit ? `&nbsp;·&nbsp; <span style="color:var(--muted);font-size:.8rem">per ${best.unit}</span>` : ''}
        &nbsp;·&nbsp; ⚡ ${best.delivery}</div>
    </div>
  </div>
  <div style="text-align:center">
    <div class="best-price">₹${best.price}</div>
    <div class="best-saving">Save ₹${saved} &nbsp;(${best.discount}% off MRP ₹${best.mrp})</div>
    ${best.bankOffers && best.bankOffers[0] ? `<div style="font-size:.76rem;color:var(--accent2);margin-top:6px">🏦 ${best.bankOffers[0]}</div>` : ''}
  </div>
  <div style="display:flex;flex-direction:column;gap:8px;min-width:150px">
    <a class="buy-btn" href="${best.buyLink}" target="_blank" rel="noopener">Buy on ${best.platform.name} →</a>
    <button class="btn-secondary" style="text-align:center" onclick="copyLink('${best.buyLink.replace(/'/g,"\\'")}',this)">📋 Copy Link</button>
  </div>`;
}

// ── Stats row ───────────────────────────────────────────────
function renderStats(data) {
  const prices = data.map(d => d.price);
  const min    = Math.min(...prices);
  const max    = Math.max(...prices);
  const avg    = Math.round(prices.reduce((a, b) => a + b) / prices.length);
  const maxD   = Math.max(...data.map(d => d.discount));
  const best   = data.find(d => d.price === min);

  document.getElementById('statsRow').innerHTML = `
  <div class="stat-card" style="animation-delay:.05s">
    <div class="stat-label">Lowest Price</div>
    <div class="stat-value" style="color:var(--accent)">₹${min}</div>
    <div class="stat-sub">${best.platform.name}</div>
  </div>
  <div class="stat-card" style="animation-delay:.1s">
    <div class="stat-label">Highest Price</div>
    <div class="stat-value" style="color:var(--danger)">₹${max}</div>
    <div class="stat-sub">${data.find(d => d.price === max).platform.name}</div>
  </div>
  <div class="stat-card" style="animation-delay:.15s">
    <div class="stat-label">Avg Price</div>
    <div class="stat-value" style="color:var(--accent2)">₹${avg}</div>
    <div class="stat-sub">Across all listings</div>
  </div>
  <div class="stat-card" style="animation-delay:.2s">
    <div class="stat-label">Total Listings</div>
    <div class="stat-value" style="color:var(--warn)">${data.length}</div>
    <div class="stat-sub">Across 5 platforms</div>
  </div>
  <div class="stat-card" style="animation-delay:.25s">
    <div class="stat-label">Max Discount</div>
    <div class="stat-value" style="color:var(--accent)">${maxD}%</div>
    <div class="stat-sub">Best offer available</div>
  </div>`;
}

// ── Platform tabs with all products ─────────────────────────
function renderPlatformTabs(data, query) {
  const platformNames = ['Amazon','Flipkart','BigBasket','JioMart','Blinkit'];

  // Group by platform
  const grouped = {};
  platformNames.forEach(name => { grouped[name] = []; });
  data.forEach(d => {
    const name = d.platform.name;
    if (grouped[name]) grouped[name].push(d);
  });

  const tabsHtml = platformNames.map((name, i) => {
    const count = grouped[name].length;
    const plat  = PLATFORMS.find(p => p.name === name);
    const minP  = count ? Math.min(...grouped[name].map(d => d.price)) : '-';
    return `<button class="plat-tab ${i === 0 ? 'active' : ''}"
      data-plat="${name}"
      style="${i === 0 ? `border-color:${plat.color};color:${plat.color}` : ''}">
      <span class="plat-tab-dot" style="background:${plat.color}"></span>
      ${name}
      <span class="plat-tab-count">${count}</span>
      ${count ? `<span class="plat-tab-min">from ₹${minP}</span>` : ''}
    </button>`;
  }).join('');

  const allProductsHtml = platformNames.map((name, i) => `
    <div class="plat-pane ${i === 0 ? 'active' : ''}" id="plat-${name.replace(/\s/g,'')}">
      ${renderProductGrid(grouped[name], name)}
    </div>`).join('');

  document.getElementById('platformCards').innerHTML = `
  <div class="plat-tabs">${tabsHtml}</div>
  <div class="plat-panes">${allProductsHtml}</div>`;

  // Tab click events
  document.querySelectorAll('.plat-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.plat-tab').forEach(b => {
        b.classList.remove('active');
        b.style.borderColor = '';
        b.style.color = '';
      });
      document.querySelectorAll('.plat-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const plat = PLATFORMS.find(p => p.name === btn.dataset.plat);
      if (plat) { btn.style.borderColor = plat.color; btn.style.color = plat.color; }
      document.getElementById('plat-' + btn.dataset.plat.replace(/\s/g,'')).classList.add('active');
    });
  });
}

function renderProductGrid(products, platformName) {
  if (!products.length) return `<div style="padding:32px;text-align:center;color:var(--muted)">No products found on ${platformName}.</div>`;

  return `<div class="product-grid">
    ${products.map((d, i) => {
      const acCls  = d.availability === 'In Stock' ? 'avail-yes' : d.availability === 'Few Left' ? 'avail-few' : 'avail-no';
      const acIcon = d.availability === 'In Stock' ? '✓' : d.availability === 'Few Left' ? '⚠' : '✗';
      return `
      <div class="product-tile ${i === 0 ? 'tile-best' : ''}" style="animation-delay:${i * 0.04}s">
        <div class="tile-img">${renderImage(d, 56)}</div>
        <div class="tile-body">
          <div class="tile-name" title="${d.productName}">${d.productName}</div>
          <div class="tile-price-row">
            <span class="tile-price" style="color:${i === 0 ? 'var(--accent)' : 'var(--text)'}">₹${d.price}</span>
            ${d.mrp > d.price ? `<span class="tile-mrp">₹${d.mrp}</span>` : ''}
            ${d.discount > 0 ? `<span class="tile-dis">-${d.discount}%</span>` : ''}
          </div>
          <div class="tile-meta">
            <span class="${acCls}" style="font-size:.72rem">${acIcon} ${d.availability}</span>
            ${d.unit ? `<span style="color:var(--muted);font-size:.72rem">· per ${d.unit}</span>` : ''}
          </div>
          ${d.delivery ? `<div style="font-size:.72rem;color:var(--muted);margin-top:2px">⚡ ${d.delivery}</div>` : ''}
        </div>
        <div class="tile-actions">
          <a class="btn-buy" href="${d.buyLink}" target="_blank" rel="noopener" style="font-size:.76rem;padding:6px 12px">Buy →</a>
          <button class="copy-btn" onclick="copyLink('${d.buyLink.replace(/\\/g,'\\\\').replace(/'/g,"\\'")}',this)" style="font-size:.72rem;padding:4px 8px">📋</button>
        </div>
        ${d.bankOffers && d.bankOffers[0] ? `<div class="tile-offer">🏦 ${d.bankOffers[0]}</div>` : ''}
        ${i === 0 ? `<div class="tile-best-badge">⭐ Best Price</div>` : ''}
      </div>`;
    }).join('')}
  </div>`;
}

// ── Bank offers grid ────────────────────────────────────────
function renderGlobalOffers(offers) {
  if (!offers || !offers.length) {
    document.getElementById('offersGrid').innerHTML = '<p style="color:var(--muted);font-size:.85rem">No offers available.</p>';
    return;
  }
  document.getElementById('offersGrid').innerHTML = offers.map(o => {
    const p  = PLATFORM_MAP[o.platform] || { color:'#8b949e', bg:'#21262d', short:'?' };
    const tc = OFFER_TAG_COLOR[o.type]  || 'blue';
    const tl = OFFER_TAG_LABEL[o.type]  || o.type;
    return `
    <div class="offer-card">
      <div class="offer-icon" style="background:${p.bg};color:${p.color};border:1px solid ${p.color}44">${p.short}</div>
      <div class="offer-body">
        <div class="offer-platform-name">${o.platform} &nbsp;·&nbsp; ${o.bank}</div>
        <div class="offer-title">${o.title}</div>
        <div class="offer-desc">${o.description}</div>
        <span class="offer-tag ${tc}">${tl}</span>
      </div>
    </div>`;
  }).join('');
}

// ── Price bar chart (one bar per platform — best price) ─────
function renderChart(data) {
  // Use lowest price per platform for chart
  const byPlatform = {};
  data.forEach(d => {
    const n = d.platform.name;
    if (!byPlatform[n] || d.price < byPlatform[n].price) byPlatform[n] = d;
  });
  const chartData = Object.values(byPlatform);
  const maxP = Math.max(...chartData.map(d => d.price));

  document.getElementById('barChart').innerHTML = chartData.map(d => {
    const pct = Math.round((d.price / maxP) * 100);
    return `
    <div class="bar-row">
      <div class="bar-label">${d.platform.name}</div>
      <div class="bar-track">
        <div class="bar-fill" data-pct="${pct}" style="background:${d.platform.color};width:0%">₹${d.price}</div>
      </div>
    </div>`;
  }).join('');

  requestAnimationFrame(() => {
    document.querySelectorAll('.bar-fill').forEach(b => {
      setTimeout(() => { b.style.width = b.dataset.pct + '%'; }, 50);
    });
  });
}

// ── Price History Chart (Chart.js) ──────────────────────────
let priceHistoryChartInstance = null;

function generatePriceHistory(currentPrice, days = 30) {
  // Simulate 30-day price history ending at today's actual price
  const prices = [];
  let price = currentPrice * (0.85 + Math.random() * 0.25); // start ±15%
  for (let i = 0; i < days; i++) {
    const noise = (Math.random() - 0.48) * (currentPrice * 0.04);
    price = Math.max(currentPrice * 0.6, Math.min(currentPrice * 1.5, price + noise));
    if (i === days - 1) price = currentPrice; // anchor last point to real price
    prices.push(Math.round(price));
  }
  return prices;
}

function getDateLabels(days = 30) {
  const labels = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    labels.push(d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }));
  }
  return labels;
}

function renderPriceHistory(data) {
  // Get best price per platform
  const byPlatform = {};
  data.forEach(d => {
    const n = d.platform.name;
    if (!byPlatform[n] || d.price < byPlatform[n].price) byPlatform[n] = d;
  });
  const platforms = Object.values(byPlatform);

  const labels = getDateLabels(30);
  const datasets = platforms.map(p => {
    const history = generatePriceHistory(p.price, 30);
    return {
      label: p.platform.name,
      data: history,
      borderColor: p.platform.color,
      backgroundColor: p.platform.color + '18',
      pointBackgroundColor: p.platform.color,
      pointRadius: 2,
      pointHoverRadius: 6,
      borderWidth: 2.5,
      tension: 0.42,
      fill: false,
    };
  });

  // Destroy old chart if exists
  if (priceHistoryChartInstance) {
    priceHistoryChartInstance.destroy();
    priceHistoryChartInstance = null;
  }

  const ctx = document.getElementById('priceHistoryChart');
  if (!ctx) return;

  priceHistoryChartInstance = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets },
    options: {
      responsive: true,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            color: '#a0aec0',
            font: { size: 12, family: "'DM Sans', sans-serif" },
            usePointStyle: true,
            pointStyleWidth: 10,
            boxHeight: 6,
            padding: 16,
          }
        },
        tooltip: {
          backgroundColor: '#1a1a2e',
          borderColor: '#2d2d4e',
          borderWidth: 1,
          titleColor: '#e2e8f0',
          bodyColor: '#a0aec0',
          padding: 12,
          callbacks: {
            label: ctx => ` ${ctx.dataset.label}: ₹${ctx.parsed.y}`
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: '#718096',
            font: { size: 10.5 },
            maxRotation: 0,
            maxTicksLimit: 8,
          },
          grid: { color: 'rgba(255,255,255,0.04)' },
          border: { color: 'rgba(255,255,255,0.08)' }
        },
        y: {
          ticks: {
            color: '#718096',
            font: { size: 11 },
            callback: v => '₹' + v,
          },
          grid: { color: 'rgba(255,255,255,0.06)' },
          border: { color: 'rgba(255,255,255,0.08)' }
        }
      }
    }
  });

  // Render history stats cards
  const statsEl = document.getElementById('historyStats');
  if (!statsEl) return;
  statsEl.innerHTML = platforms.map(p => {
    const hist = datasets.find(d => d.label === p.platform.name).data;
    const minP = Math.min(...hist);
    const maxP = Math.max(...hist);
    const first = hist[0], last = hist[hist.length - 1];
    const change = last - first;
    const changePct = Math.abs(Math.round((change / first) * 100));
    const trendClass = change > 2 ? 'trend-up' : change < -2 ? 'trend-down' : 'trend-flat';
    const trendText  = change > 2 ? `▲ +₹${change} this month` : change < -2 ? `▼ -₹${Math.abs(change)} this month` : '→ Stable';
    return `
    <div class="hstat-card">
      <div class="hstat-platform" style="color:${p.platform.color}">${p.platform.name}</div>
      <div class="hstat-row"><span>Today</span><strong>₹${last}</strong></div>
      <div class="hstat-row"><span>30-day low</span><strong>₹${minP}</strong></div>
      <div class="hstat-row"><span>30-day high</span><strong>₹${maxP}</strong></div>
      <div class="hstat-trend ${trendClass}">${trendText} (${changePct}%)</div>
    </div>`;
  }).join('');
}
