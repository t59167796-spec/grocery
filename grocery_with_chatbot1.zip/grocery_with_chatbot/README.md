# GrocerySmart

A grocery price-comparison app (Amazon / Flipkart / BigBasket / JioMart / Blinkit) with a recipe chatbot ("ChefBot") that lists ingredients for a dish and lets you tap any ingredient to compare its price across platforms.

## Project structure

```
grocery_with_chatbot/
├── index.html          # Frontend entry point
├── css/style.css        # Styles
├── js/
│   ├── config.js         # Platform definitions
│   ├── api.js            # Fetches prices (via backend, or falls back to fake data)
│   ├── images.js          # Product image helpers
│   ├── render.js           # Renders results, charts, price history
│   ├── app.js               # Search, sort, save-product logic
│   ├── url.js                # "Paste a product URL" tab logic
│   └── chatbot.js             # Recipe chatbot frontend
└── backend/
    ├── server.js               # Express server — proxies Anthropic API, serves frontend
    ├── chatbot-route.js         # POST /api/chatbot/message
    ├── recipes.js                # Local recipe database (~50 dishes, no API call needed)
    ├── package.json
    └── .env.example                # Copy to .env and add your API key
```

## Setup

1. Install dependencies:
   ```bash
   cd backend
   npm install
   ```

2. Add your Anthropic API key:
   ```bash
   cp .env.example .env
   # then edit .env and set ANTHROPIC_API_KEY=sk-ant-...
   ```
   Get a key from https://console.anthropic.com/settings/keys

3. Run the server:
   ```bash
   node server.js
   # or, for auto-restart on file changes:
   npm run dev
   ```

4. Open **http://localhost:3001** in your browser.

## How it behaves without an API key

- The **recipe chatbot** still works instantly for ~50 common Indian dishes (dosa, biryani, chole, etc.) because those are served from `backend/recipes.js` with no API call.
- Asking about a dish **not** in that local list, or using the **price search / URL compare** tabs, requires the Anthropic API and will return a clear error (`ANTHROPIC_API_KEY is not set`) until you add a key in `.env`.

## Notes

- The backend keeps your API key server-side — the frontend never sees it. `js/api.js` and `js/chatbot.js` include a "direct browser → Claude API" fallback path for when `index.html` is opened without the backend running (e.g. via `file://`), but since that path can't safely carry a private API key, it will fail and the app falls back to realistic-looking placeholder data instead. This is expected — always run the app through the backend for real data.
- `node_modules/` and `.env` are git-ignored; run `npm install` after cloning.
